// Base User Interface
export interface BaseUser {
  id: string;
  username: string;
  email?: string;
  phone?: string;
  role: 'admin' | 'provider' | 'patient';
  full_name: string;
  is_active: boolean;
  preferred_language: 'en' | 'ar';
  created_at: string;
  updated_at: string;
}

// Provider Interface
export interface Provider extends BaseUser {
  role: 'provider';
  national_id?: string;
  patients_count?: number;
}

// Patient Interface
export interface Patient extends BaseUser {
  role: 'patient';
  mrn: string;
  date_of_birth: string;
  address?: string;
  whatsapp?: string;
  emergency_contact_1?: string;
  emergency_contact_2?: string;
  medical_report?: string;
  clinical_history?: string;
  physical_exam?: string;
  care_plan?: string;
  icd10_codes?: string[];
  call_frequency_value?: number;
  call_frequency_unit?: 'hours' | 'days' | 'weeks' | 'months' | 'years';
  start_date?: string;
  end_date?: string;
  preferred_voice?: string;
  preferred_accent?: string;
  suitable_call_time_start?: string;
  suitable_call_time_end?: string;
  what_to_assess?: string;
  assigned_provider_id?: string;
  do_not_call: boolean;
}

// Medication Interface
export interface Medication {
  id: string;
  patient_id: string;
  name: string;
  dosage: string;
  unit: string;
  frequency: string;
  created_at: string;
}

// Call Log Interface
export interface CallLog {
  id: string;
  patient_id: string;
  provider_id?: string;
  call_date: string;
  start_time: string;
  end_time?: string | null;
  duration_minutes?: number | null;
  action_type: string;
  transcription?: string | null;
  call_status: 'success' | 'failed' | 'missed';
  created_at: string;
}

// System Settings Interface
export interface SystemSettings {
  systemName: string;
  systemSlogan: string;
  headerLogoUrl?: string;
  portalLogoUrl?: string;
  adminEmail?: string;
  adminPhone?: string;
  costPerMinute: number;
  llm_provider: 'openai' | 'anthropic' | 'google';
  api_key: string;
  model: string;
  temperature: number;
  max_tokens: number;
}

// Navigation Item Interface
export interface NavItem {
  path: string;
  icon: any;
  label: string;
  badge?: string | null;
}

// Navigation Section Interface
export interface NavSection {
  section: string;
  title: string;
  items: NavItem[];
}

// File Upload Interface
export interface UploadedFile {
  id: string;
  name: string;
  size: number;
  uploadDate: Date;
  type: string;
  status: 'processing' | 'ready' | 'error';
  pages?: number;
}

// Prompt Template Interface
export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  content: string;
  category: 'medical' | 'general' | 'emergency' | 'custom';
}

// Data Table Column Interface
export interface DataTableColumn {
  key: string;
  label: string;
  sortable?: boolean;
  render?: (value: any, row: any) => React.ReactNode;
}

// Modal Props Interface
export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

// Form Data Interfaces
export interface PatientFormData {
  full_name: string;
  username: string;
  email: string;
  phone: string;
  whatsapp: string;
  mrn: string;
  date_of_birth: string;
  address: string;
  emergency_contact_1: string;
  emergency_contact_2: string;
  medical_report: string;
  clinical_history: string;
  physical_exam: string;
  care_plan: string;
  icd10_codes: string[];
  call_frequency_value: number;
  call_frequency_unit: 'hours' | 'days' | 'weeks' | 'months' | 'years';
  start_date: string;
  end_date: string;
  preferred_language: 'en' | 'ar';
  preferred_voice: string;
  preferred_accent: string;
  suitable_call_time_start: string;
  suitable_call_time_end: string;
  what_to_assess: string;
  assigned_provider_id: string;
  is_active: boolean;
  do_not_call: boolean;
  password: string;
}

export interface ProviderFormData {
  full_name: string;
  username: string;
  email: string;
  phone: string;
  national_id: string;
  password: string;
  is_active: boolean;
}

// Statistics Interfaces
export interface DashboardStats {
  totalProviders?: number;
  totalPatients?: number;
  totalCalls?: number;
  monthlyRevenue?: number;
  averageCallDuration?: number;
  successfulCalls?: number;
  failedCalls?: number;
}

// Export all types
export type User = BaseUser;
export type { Provider, Patient, Medication, CallLog, SystemSettings };