import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  Home, Users, Phone, Settings, FileText, DollarSign, Download,
  Heart, Activity, BarChart3, ChevronDown, X, HelpCircle, Brain
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  const location = useLocation();
  const [expandedSections, setExpandedSections] = React.useState(['main']);

  const toggleSection = (section: string) => {
    setExpandedSections(prev => 
      prev.includes(section) 
        ? prev.filter(s => s !== section)
        : [...prev, section]
    );
  };

  const getNavItems = () => {
    const baseItems = [
      {
        section: 'main',
        title: 'Main',
        items: [
          { path: `/${user?.role}/dashboard`, icon: Home, label: t('dashboard'), badge: null },
        ]
      }
    ];

    if (user?.role === 'admin') {
      baseItems.push(
        {
          section: 'management',
          title: 'Management',
          items: [
            { path: '/admin/providers', icon: Users, label: t('providers'), badge: '12' },
            { path: '/admin/patients', icon: Users, label: t('patients'), badge: '48' },
            { path: '/admin/main-prompt', icon: Brain, label: 'AI Configuration', badge: null },
          ]
        },
        {
          section: 'reports',
          title: 'Reports & Data',
          items: [
            { path: '/admin/call-logs', icon: Phone, label: t('callLogs'), badge: null },
            { path: '/admin/financial-reports', icon: DollarSign, label: t('financialReports'), badge: null },
            { path: '/admin/export-data', icon: Download, label: t('exportData'), badge: null },
          ]
        },
        {
          section: 'settings',
          title: 'Settings',
          items: [
            { path: '/admin/settings', icon: Settings, label: t('settings'), badge: null },
          ]
        }
      );
    } else if (user?.role === 'provider') {
      baseItems.push(
        {
          section: 'patient-care',
          title: 'Patient Care',
          items: [
            { path: '/provider/patients', icon: Users, label: t('patients'), badge: '24' },
            { path: '/provider/call-logs', icon: Phone, label: t('callLogs'), badge: null },
          ]
        },
        {
          section: 'settings',
          title: 'Settings',
          items: [
            { path: '/provider/settings', icon: Settings, label: t('settings'), badge: null },
          ]
        }
      );
    } else if (user?.role === 'patient') {
      baseItems.push(
        {
          section: 'care',
          title: 'My Care',
          items: [
            { path: '/patient/care-plan', icon: FileText, label: t('carePlan'), badge: null },
            { path: '/patient/help-center', icon: HelpCircle, label: t('helpCenter'), badge: null },
          ]
        },
        {
          section: 'settings',
          title: 'Settings',
          items: [
            { path: '/patient/settings', icon: Settings, label: t('settings'), badge: null },
          ]
        }
      );
    }

    return baseItems;
  };

  const navSections = getNavItems();

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed top-0 ${isRTL ? 'right-0' : 'left-0'} h-full w-72 bg-white shadow-xl z-50
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : isRTL ? 'translate-x-full' : '-translate-x-full'}
        lg:translate-x-0 lg:static lg:z-auto border-r border-gray-200
      `}>
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b lg:hidden bg-gradient-to-r from-viking/5 to-medium-purple/5">
          <h2 className="text-lg font-bold text-chathams-blue">{t('navigation')}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Profile Section */}
        <div className="p-6 bg-gradient-to-r from-viking/5 to-medium-purple/5 border-b">
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <div className="w-12 h-12 bg-gradient-to-r from-viking to-medium-purple rounded-xl flex items-center justify-center shadow-lg">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <div className={isRTL ? 'text-right' : ''}>
              <p className="font-bold text-gray-900">{user?.full_name || user?.username}</p>
              <p className="text-sm text-gray-500 capitalize">{user?.role}</p>
              <div className="flex items-center gap-1 mt-1">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs text-green-600">Online</span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2 flex-1 overflow-y-auto">
          {navSections.map((section) => (
            <div key={section.section} className="mb-6">
              <button
                onClick={() => toggleSection(section.section)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:text-gray-700 transition-colors ${isRTL ? 'flex-row-reverse' : ''}`}
              >
                <span>{section.title}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${expandedSections.includes(section.section) ? 'rotate-180' : ''}`} />
              </button>
              
              {expandedSections.includes(section.section) && (
                <div className="mt-2 space-y-1">
                  {section.items.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;
                    
                    return (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        onClick={onClose}
                        className={`
                          flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group
                          ${isActive 
                            ? 'bg-gradient-to-r from-viking to-medium-purple text-white shadow-lg transform scale-105' 
                            : 'text-gray-700 hover:bg-gray-100 hover:text-chathams-blue hover:transform hover:scale-105'
                          }
                          ${isRTL ? 'flex-row-reverse' : ''}
                        `}
                      >
                        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <Icon className="w-5 h-5" />
                          <span className="font-medium">{item.label}</span>
                        </div>
                        {item.badge && (
                          <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                            isActive 
                              ? 'bg-white/20 text-white' 
                              : 'bg-gray-200 text-gray-600 group-hover:bg-viking/10 group-hover:text-viking'
                          }`}>
                            {item.badge}
                          </span>
                        )}
                      </NavLink>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Quick Stats */}
        <div className="p-4 border-t bg-gray-50">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white p-3 rounded-lg border">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-green-500" />
                <span className="text-xs text-gray-600">System</span>
              </div>
              <p className="text-sm font-bold text-gray-900">Online</p>
            </div>
            <div className="bg-white p-3 rounded-lg border">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-500" />
                <span className="text-xs text-gray-600">Usage</span>
              </div>
              <p className="text-sm font-bold text-gray-900">87%</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;