import React, { useState } from 'react';
import { Shield, Users, Activity, Heart, ArrowRight, CheckCircle, Star, Phone, Mail, MapPin } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import LoginForm from '../components/Common/LoginForm';

const Landing: React.FC = () => {
  const { systemSettings } = useAuth();
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<'admin' | 'provider' | 'patient'>('admin');

  const roleOptions = [
    {
      role: 'admin' as const,
      title: 'Administrator Portal',
      icon: Shield,
      color: 'from-red-500 to-red-600',
      hoverColor: 'hover:from-red-600 hover:to-red-700',
      description: 'System administration and management',
      features: ['User Management', 'System Configuration', 'Reports & Analytics', 'Data Export']
    },
    {
      role: 'provider' as const,
      title: 'Healthcare Provider Portal',
      icon: Users,
      color: 'from-blue-500 to-blue-600',
      hoverColor: 'hover:from-blue-600 hover:to-blue-700',
      description: 'Professional healthcare management',
      features: ['Patient Management', 'Call Scheduling', 'Medical Records', 'Care Plans']
    },
    {
      role: 'patient' as const,
      title: 'Patient Portal',
      icon: Heart,
      color: 'from-green-500 to-green-600',
      hoverColor: 'hover:from-green-600 hover:to-green-700',
      description: 'Personal health management',
      features: ['Care Plan Access', 'Health Monitoring', 'Provider Communication', 'Medical History']
    }
  ];

  const handleRoleSelect = (role: 'admin' | 'provider' | 'patient') => {
    setSelectedRole(role);
    setIsLoginOpen(true);
  };

  const features = [
    {
      icon: Activity,
      title: 'AI-Powered Monitoring',
      description: 'Advanced artificial intelligence monitors patient health 24/7 with real-time alerts and insights.'
    },
    {
      icon: Phone,
      title: 'Automated Calling',
      description: 'Intelligent voice calls check on patients regularly, ensuring continuous care and support.'
    },
    {
      icon: Shield,
      title: 'Secure & Compliant',
      description: 'HIPAA-compliant platform with enterprise-grade security protecting sensitive health data.'
    },
    {
      icon: Users,
      title: 'Multi-Role Access',
      description: 'Dedicated portals for administrators, healthcare providers, and patients with role-based permissions.'
    }
  ];

  const testimonials = [
    {
      name: 'Dr. Sarah Johnson',
      role: 'Healthcare Provider',
      content: 'This platform has revolutionized how we monitor our patients. The AI insights are incredibly valuable.',
      rating: 5
    },
    {
      name: 'Ahmad Al-Rashid',
      role: 'Patient',
      content: 'I feel more connected to my healthcare team. The regular check-ins give me peace of mind.',
      rating: 5
    },
    {
      name: 'Hospital Administrator',
      role: 'Healthcare System',
      content: 'The efficiency gains and improved patient outcomes have been remarkable since implementation.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-viking to-medium-purple rounded-xl flex items-center justify-center shadow-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-chathams-blue">{systemSettings.systemName}</h1>
                <p className="text-xs text-gray-600">Healthcare Platform</p>
              </div>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#features" className="text-gray-600 hover:text-chathams-blue transition-colors">Features</a>
              <a href="#testimonials" className="text-gray-600 hover:text-chathams-blue transition-colors">Testimonials</a>
              <a href="#contact" className="text-gray-600 hover:text-chathams-blue transition-colors">Contact</a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-grid-pattern bg-grid opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-chathams-blue mb-6 animate-fade-in">
              Welcome to {systemSettings.systemName}
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto animate-slide-up">
              {systemSettings.systemSlogan}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <button className="px-8 py-4 bg-gradient-to-r from-viking to-medium-purple text-white rounded-xl font-semibold hover:shadow-lg transform hover:scale-105 transition-all duration-200">
                Get Started
                <ArrowRight className="w-5 h-5 ml-2 inline" />
              </button>
              <button className="px-8 py-4 border-2 border-chathams-blue text-chathams-blue rounded-xl font-semibold hover:bg-chathams-blue hover:text-white transition-all duration-200">
                Learn More
              </button>
            </div>
          </div>

          {/* Role Selection Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {roleOptions.map((option) => {
              const Icon = option.icon;
              return (
                <div
                  key={option.role}
                  onClick={() => handleRoleSelect(option.role)}
                  className={`
                    relative group cursor-pointer transform transition-all duration-300 hover:scale-105 hover:shadow-2xl
                    bg-white rounded-2xl p-8 shadow-lg border border-gray-100
                    ${option.hoverColor}
                  `}
                >
                  <div className={`w-16 h-16 bg-gradient-to-r ${option.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-white transition-colors duration-300">
                    {option.title}
                  </h3>
                  
                  <p className="text-gray-600 mb-6 group-hover:text-white/90 transition-colors duration-300">
                    {option.description}
                  </p>
                  
                  <ul className="space-y-2 mb-6">
                    {option.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm text-gray-600 group-hover:text-white/80 transition-colors duration-300">
                        <CheckCircle className="w-4 h-4 text-green-500 group-hover:text-white/80" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <button className="w-full py-3 bg-gray-100 text-gray-700 rounded-xl font-semibold group-hover:bg-white/20 group-hover:text-white transition-all duration-300 hover:shadow-md">
                    Access Portal
                    <ArrowRight className="w-4 h-4 ml-2 inline group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-chathams-blue mb-4">Powerful Features</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Advanced healthcare technology designed to improve patient outcomes and streamline care delivery.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center group hover:transform hover:scale-105 transition-all duration-300">
                  <div className="w-16 h-16 bg-gradient-to-r from-viking to-medium-purple rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:shadow-lg transition-shadow duration-300">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-chathams-blue mb-4">What Our Users Say</h2>
            <p className="text-xl text-gray-600">Trusted by healthcare professionals and patients worldwide.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 italic">"{testimonial.content}"</p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-chathams-blue text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-viking to-medium-purple rounded-xl flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold">{systemSettings.systemName}</h3>
              </div>
              <p className="text-blue-200 mb-6 max-w-md">
                Revolutionizing healthcare with AI-powered remote patient monitoring and intelligent care coordination.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span className="text-blue-200">{systemSettings.adminPhone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span className="text-blue-200">{systemSettings.adminEmail}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span className="text-blue-200">Healthcare District, Saudi Arabia</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2">
                <a href="#features" className="block text-blue-200 hover:text-white transition-colors">Features</a>
                <a href="#testimonials" className="block text-blue-200 hover:text-white transition-colors">Testimonials</a>
                <a href="#contact" className="block text-blue-200 hover:text-white transition-colors">Contact</a>
                <a href="#" className="block text-blue-200 hover:text-white transition-colors">Privacy Policy</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-blue-600 mt-12 pt-8 text-center">
            <p className="text-blue-200">
              © 2024 {systemSettings.systemName}. All rights reserved. | Advanced Healthcare Technology Platform
            </p>
          </div>
        </div>
      </footer>

      {/* Login Modal */}
      <LoginForm
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        selectedRole={selectedRole}
      />
    </div>
  );
};

export default Landing;