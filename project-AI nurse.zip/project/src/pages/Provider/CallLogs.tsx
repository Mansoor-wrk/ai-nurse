import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Phone, Download, Search, Filter } from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import { CallLog } from '../../types';

const ProviderCallLogs: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const [callLogs] = useState<CallLog[]>([
    {
      id: '1',
      patient_id: '1',
      provider_id: '1',
      call_date: '2024-01-15',
      start_time: '10:00:00',
      end_time: '10:15:00',
      duration_minutes: 15,
      action_type: 'Follow-up Assessment',
      transcription: 'Patient reported feeling better. Blood glucose levels stable at 120 mg/dL. Medication compliance good.',
      call_status: 'success',
      created_at: '2024-01-15T10:15:00Z',
    },
    {
      id: '2',
      patient_id: '2',
      provider_id: '1',
      call_date: '2024-01-14',
      start_time: '14:30:00',
      end_time: '14:42:00',
      duration_minutes: 12,
      action_type: 'Blood Pressure Check',
      transcription: 'Patient reports BP readings: 140/90 this morning, 135/85 yesterday evening. Discussed medication timing.',
      call_status: 'success',
      created_at: '2024-01-14T14:42:00Z',
    },
    {
      id: '3',
      patient_id: '1',
      call_date: '2024-01-12',
      start_time: '09:00:00',
      end_time: null,
      duration_minutes: null,
      action_type: 'Scheduled Check-in',
      transcription: null,
      call_status: 'missed',
      created_at: '2024-01-12T09:00:00Z',
    },
    {
      id: '4',
      patient_id: '2',
      provider_id: '1',
      call_date: '2024-01-10',
      start_time: '11:15:00',
      end_time: '11:28:00',
      duration_minutes: 13,
      action_type: 'Medication Review',
      transcription: 'Reviewed current medications. Patient experiencing mild dizziness. Advised to take BP medication with food.',
      call_status: 'success',
      created_at: '2024-01-10T11:28:00Z',
    },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('');

  const columns = [
    {
      key: 'call_date',
      label: 'Date',
      sortable: true,
      render: (value: string) => new Date(value).toLocaleDateString(),
    },
    {
      key: 'start_time',
      label: 'Start Time',
      render: (value: string) => value.substring(0, 5),
    },
    {
      key: 'end_time',
      label: 'End Time',
      render: (value: string | null) => value ? value.substring(0, 5) : 'N/A',
    },
    {
      key: 'duration_minutes',
      label: 'Duration',
      render: (value: number | null) => value ? `${value} min` : 'N/A',
    },
    {
      key: 'action_type',
      label: 'Action Type',
      sortable: true,
    },
    {
      key: 'call_status',
      label: 'Status',
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
          value === 'success' ? 'bg-green-100 text-green-800' :
          value === 'failed' ? 'bg-red-100 text-red-800' :
          'bg-yellow-100 text-yellow-800'
        }`}>
          {value.charAt(0).toUpperCase() + value.slice(1)}
        </span>
      ),
    },
    {
      key: 'patient_id',
      label: 'Patient',
      render: (value: string) => {
        const patientNames: { [key: string]: string } = {
          '1': 'Ahmad Al-Rashid',
          '2': 'Fatima Hassan',
        };
        return patientNames[value] || `Patient ${value}`;
      },
    },
  ];

  const filteredLogs = callLogs.filter(log => {
    const matchesSearch = searchTerm === '' || 
      log.action_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.transcription?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || log.call_status === statusFilter;
    
    const matchesDate = dateFilter === '' || log.call_date === dateFilter;
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  const handleExport = () => {
    console.log('Exporting call logs to Excel');
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Phone className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.callLogs')}</h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`grid grid-cols-1 md:grid-cols-4 gap-4 ${isRTL ? 'text-right' : ''}`}>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Search
            </label>
            <div className="relative">
              <Search className={`absolute top-3 ${isRTL ? 'right-3' : 'left-3'} w-4 h-4 text-gray-400`} />
              <input
                type="text"
                placeholder="Search by action type or transcription"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full ${isRTL ? 'pr-10 text-right' : 'pl-10'} py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking`}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            >
              <option value="all">All Status</option>
              <option value="success">Success</option>
              <option value="failed">Failed</option>
              <option value="missed">Missed</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date
            </label>
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleExport}
              className={`flex items-center gap-2 px-4 py-2 bg-viking text-white rounded-lg hover:bg-viking/90 ${isRTL ? 'flex-row-reverse' : ''}`}
            >
              <Download className="w-4 h-4" />
              Export Excel
            </button>
          </div>
        </div>
      </div>

      {/* Call Logs Table */}
      <DataTable
        data={filteredLogs}
        columns={columns}
        searchable={false}
        filterable={false}
      />

      {/* Call Details */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Call Details</h2>
        <div className="space-y-4">
          {filteredLogs.slice(0, 3).map((log) => (
            <div key={log.id} className="border border-gray-200 rounded-lg p-4">
              <div className={`flex items-center justify-between mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="font-medium text-gray-900">{log.action_type}</span>
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    log.call_status === 'success' ? 'bg-green-100 text-green-800' :
                    log.call_status === 'failed' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {log.call_status}
                  </span>
                </div>
                <div className="text-sm text-gray-500">
                  {new Date(log.call_date).toLocaleDateString()} at {log.start_time.substring(0, 5)}
                </div>
              </div>
              
              {log.transcription && (
                <div className="mt-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Transcription:
                  </label>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                    {log.transcription}
                  </p>
                </div>
              )}
              
              <div className={`flex items-center gap-4 mt-3 text-sm text-gray-500 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span>Patient: {log.patient_id === '1' ? 'Ahmad Al-Rashid' : 'Fatima Hassan'}</span>
                {log.duration_minutes && <span>Duration: {log.duration_minutes} minutes</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProviderCallLogs;