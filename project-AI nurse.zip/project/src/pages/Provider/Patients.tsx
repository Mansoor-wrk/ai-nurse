import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Users, Plus, Eye, Edit, Trash2 } from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import Modal from '../../components/Common/Modal';
import { Patient, Medication } from '../../types';

const ProviderPatients: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const [patients, setPatients] = useState<Patient[]>([
    {
      id: '1',
      username: 'ahmad_patient',
      email: 'ahmad@example.com',
      phone: '+966501234570',
      role: 'patient',
      full_name: 'Ahmad Al-Rashid',
      is_active: true,
      preferred_language: 'ar',
      created_at: '2024-01-15T10:00:00Z',
      updated_at: '2024-01-15T10:00:00Z',
      mrn: 'MRN001',
      date_of_birth: '1985-05-15',
      address: 'Riyadh, Saudi Arabia',
      whatsapp: '+966501234570',
      emergency_contact_1: '+966501234571',
      emergency_contact_2: '+966501234572',
      medical_report: 'Patient presents with diabetes type 2',
      clinical_history: 'Diagnosed with diabetes in 2020',
      physical_exam: 'Normal vital signs',
      care_plan: 'Monitor blood glucose levels daily',
      icd10_codes: ['E11.9'],
      call_frequency_value: 1,
      call_frequency_unit: 'weeks',
      start_date: '2024-01-01',
      end_date: '2024-12-31',
      preferred_voice: 'female',
      preferred_accent: 'saudi',
      suitable_call_time_start: '09:00',
      suitable_call_time_end: '17:00',
      what_to_assess: 'Blood glucose levels, medication compliance',
      assigned_provider_id: '1',
      do_not_call: false,
    },
    {
      id: '2',
      username: 'fatima_patient',
      email: 'fatima@example.com',
      phone: '+966501234571',
      role: 'patient',
      full_name: 'Fatima Hassan',
      is_active: true,
      preferred_language: 'ar',
      created_at: '2024-01-10T10:00:00Z',
      updated_at: '2024-01-10T10:00:00Z',
      mrn: 'MRN002',
      date_of_birth: '1990-08-22',
      address: 'Jeddah, Saudi Arabia',
      whatsapp: '+966501234571',
      emergency_contact_1: '+966501234572',
      emergency_contact_2: '+966501234573',
      medical_report: 'Hypertension management',
      clinical_history: 'Family history of cardiovascular disease',
      physical_exam: 'Elevated blood pressure',
      care_plan: 'Daily blood pressure monitoring',
      icd10_codes: ['I10'],
      call_frequency_value: 2,
      call_frequency_unit: 'weeks',
      start_date: '2024-01-01',
      end_date: '2024-12-31',
      preferred_voice: 'female',
      preferred_accent: 'saudi',
      suitable_call_time_start: '10:00',
      suitable_call_time_end: '16:00',
      what_to_assess: 'Blood pressure readings, medication adherence',
      assigned_provider_id: '1',
      do_not_call: false,
    },
  ]);

  const [medications] = useState<Medication[]>([
    {
      id: '1',
      patient_id: '1',
      name: 'Metformin',
      dosage: '500',
      unit: 'mg',
      frequency: 'twice daily',
      created_at: '2024-01-15T10:00:00Z',
    },
    {
      id: '2',
      patient_id: '2',
      name: 'Lisinopril',
      dosage: '10',
      unit: 'mg',
      frequency: 'once daily',
      created_at: '2024-01-10T10:00:00Z',
    },
  ]);

  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [viewingPatient, setViewingPatient] = useState<Patient | null>(null);

  const columns = [
    {
      key: 'mrn',
      label: 'MRN',
      sortable: true,
    },
    {
      key: 'full_name',
      label: 'Name',
      sortable: true,
    },
    {
      key: 'date_of_birth',
      label: 'DOB',
      render: (value: string) => new Date(value).toLocaleDateString(),
    },
    {
      key: 'phone',
      label: 'Phone',
    },
    {
      key: 'preferred_language',
      label: 'Language',
      render: (value: string) => value === 'ar' ? 'العربية' : 'English',
    },
    {
      key: 'call_frequency_value',
      label: 'Call Schedule',
      render: (value: number, row: Patient) => 
        `Every ${value} ${row.call_frequency_unit}`,
    },
    {
      key: 'is_active',
      label: 'Status',
      render: (value: boolean) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {value ? t('common.active') : t('common.inactive')}
        </span>
      ),
    },
  ];

  const handleView = (patient: Patient) => {
    setViewingPatient(patient);
    setIsViewModalOpen(true);
  };

  const handleEdit = (patient: Patient) => {
    // Navigate to edit patient or open edit modal
    console.log('Edit patient:', patient.id);
  };

  const handleDelete = (patient: Patient) => {
    if (confirm('Are you sure you want to remove this patient from your care?')) {
      setPatients(prev => prev.filter(p => p.id !== patient.id));
    }
  };

  const handleExport = () => {
    console.log('Exporting patients data to Excel');
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Users className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('provider.myPatients')}</h1>
      </div>

      <DataTable
        data={patients}
        columns={columns}
        onView={handleView}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onExport={handleExport}
      />

      {/* View Patient Modal */}
      <Modal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title={`Patient File: ${viewingPatient?.full_name}`}
        size="xl"
      >
        {viewingPatient && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">MRN</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.mrn}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Date of Birth</label>
                <p className="mt-1 text-sm text-gray-900">{new Date(viewingPatient.date_of_birth).toLocaleDateString()}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Phone</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.phone}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">WhatsApp</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.whatsapp || 'N/A'}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Emergency Contact 1</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.emergency_contact_1 || 'N/A'}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Emergency Contact 2</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.emergency_contact_2 || 'N/A'}</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Address</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.address || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Medical Report (SOAP)</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.medical_report || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Clinical History</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.clinical_history || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Physical Examination</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.physical_exam || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Care Plan</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.care_plan || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">What to Assess</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.what_to_assess || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Medications</label>
              <div className="mt-1 space-y-2">
                {medications.filter(m => m.patient_id === viewingPatient.id).map(med => (
                  <div key={med.id} className="bg-gray-50 p-2 rounded text-sm">
                    <strong>{med.name}</strong> - {med.dosage}{med.unit} - {med.frequency}
                  </div>
                ))}
                {medications.filter(m => m.patient_id === viewingPatient.id).length === 0 && (
                  <p className="text-gray-500 text-sm">No medications recorded</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Call Frequency</label>
                <p className="mt-1 text-sm text-gray-900">
                  Every {viewingPatient.call_frequency_value} {viewingPatient.call_frequency_unit}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Call Times</label>
                <p className="mt-1 text-sm text-gray-900">
                  {viewingPatient.suitable_call_time_start} - {viewingPatient.suitable_call_time_end}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Preferred Language</label>
                <p className="mt-1 text-sm text-gray-900">
                  {viewingPatient.preferred_language === 'ar' ? 'العربية' : 'English'}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Preferred Voice</label>
                <p className="mt-1 text-sm text-gray-900 capitalize">{viewingPatient.preferred_voice}</p>
              </div>
            </div>

            {viewingPatient.icd10_codes && viewingPatient.icd10_codes.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700">ICD-10 Codes</label>
                <div className="mt-1 flex flex-wrap gap-2">
                  {viewingPatient.icd10_codes.map(code => (
                    <span key={code} className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm">
                      {code}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default ProviderPatients;