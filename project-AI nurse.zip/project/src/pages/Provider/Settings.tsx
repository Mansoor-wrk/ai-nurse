import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { Settings as SettingsIcon, Save, User } from 'lucide-react';

const ProviderSettings: React.FC = () => {
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  
  const [settings, setSettings] = useState({
    full_name: user?.full_name || '',
    phone: user?.phone || '',
    email: user?.email || '',
    national_id: '',
  });

  const [credentials, setCredentials] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleSettingsChange = (field: string, value: string) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleCredentialsChange = (field: string, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = () => {
    console.log('Saving provider settings:', settings);
    // Here you would typically make an API call to update the settings
  };

  const handleChangePassword = () => {
    if (credentials.newPassword !== credentials.confirmPassword) {
      alert('New passwords do not match');
      return;
    }
    console.log('Changing password');
    // Here you would typically make an API call to change the password
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <SettingsIcon className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.settings')}</h1>
      </div>

      {/* Profile Information */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <User className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Profile Information</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('common.name')}
            </label>
            <input
              type="text"
              value={settings.full_name}
              onChange={(e) => handleSettingsChange('full_name', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('common.phone')}
            </label>
            <input
              type="tel"
              value={settings.phone}
              onChange={(e) => handleSettingsChange('phone', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('common.email')}
            </label>
            <input
              type="email"
              value={settings.email}
              onChange={(e) => handleSettingsChange('email', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              National ID
            </label>
            <input
              type="text"
              value={settings.national_id}
              onChange={(e) => handleSettingsChange('national_id', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleSaveSettings}
            className={`flex items-center gap-2 px-6 py-3 bg-viking text-white rounded-lg hover:bg-viking/90 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Save className="w-5 h-5" />
            {t('common.save')}
          </button>
        </div>
      </div>

      {/* Change Password */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Change Password</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Current Password
            </label>
            <input
              type="password"
              value={credentials.currentPassword}
              onChange={(e) => handleCredentialsChange('currentPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              New Password
            </label>
            <input
              type="password"
              value={credentials.newPassword}
              onChange={(e) => handleCredentialsChange('newPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Confirm Password
            </label>
            <input
              type="password"
              value={credentials.confirmPassword}
              onChange={(e) => handleCredentialsChange('confirmPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleChangePassword}
            className={`flex items-center gap-2 px-6 py-3 bg-medium-purple text-white rounded-lg hover:bg-medium-purple/90 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Save className="w-5 h-5" />
            Change Password
          </button>
        </div>
      </div>

      {/* Current Role Information */}
      <div className="bg-gradient-to-r from-viking/10 to-medium-purple/10 rounded-xl p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Account Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Username</label>
            <p className="mt-1 text-sm text-gray-900">{user?.username}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Role</label>
            <p className="mt-1 text-sm text-gray-900 capitalize">{user?.role}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Account Status</label>
            <span className={`inline-flex px-2 py-1 rounded-full text-xs ${
              user?.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {user?.is_active ? 'Active' : 'Inactive'}
            </span>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Member Since</label>
            <p className="mt-1 text-sm text-gray-900">
              {user?.created_at ? new Date(user.created_at).toLocaleDateString() : 'N/A'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderSettings;