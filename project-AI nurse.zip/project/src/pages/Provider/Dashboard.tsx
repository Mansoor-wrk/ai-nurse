import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Users, Phone, Clock, Calendar } from 'lucide-react';

const ProviderDashboard: React.FC = () => {
  const { t } = useLanguage();

  const stats = [
    {
      icon: Users,
      title: 'My Patients',
      value: '32',
      change: '+3 new assignments',
      color: 'bg-green-500',
    },
    {
      icon: Phone,
      title: 'Calls Today',
      value: '8',
      change: '2 pending',
      color: 'bg-viking',
    },
    {
      icon: Clock,
      title: 'Average Call Duration',
      value: '12 min',
      change: '+2 min from last week',
      color: 'bg-blue-500',
    },
    {
      icon: Calendar,
      title: 'Next Scheduled Call',
      value: '2:30 PM',
      change: 'Ahmad Al-Rashid',
      color: 'bg-medium-purple',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-chathams-blue">{t('provider.title')}</h1>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <p className="text-blue-600 text-sm mt-1">{stat.change}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Today's Schedule */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Today's Schedule</h2>
        <div className="space-y-4">
          {[
            { time: '09:00 AM', patient: 'Ahmad Al-Rashid', type: 'Follow-up Call', status: 'completed' },
            { time: '10:30 AM', patient: 'Fatima Hassan', type: 'Initial Assessment', status: 'completed' },
            { time: '02:30 PM', patient: 'Omar Mohammed', type: 'Medication Review', status: 'upcoming' },
            { time: '04:00 PM', patient: 'Layla Abdullah', type: 'Care Plan Update', status: 'upcoming' },
          ].map((appointment, index) => (
            <div key={index} className={`flex items-center justify-between p-4 rounded-lg ${
              appointment.status === 'completed' ? 'bg-green-50 border-l-4 border-green-500' : 'bg-blue-50 border-l-4 border-blue-500'
            }`}>
              <div>
                <div className="flex items-center gap-3">
                  <span className="font-bold text-gray-900">{appointment.time}</span>
                  <span className="text-gray-600">•</span>
                  <span className="font-medium text-gray-900">{appointment.patient}</span>
                </div>
                <p className="text-sm text-gray-600 mt-1">{appointment.type}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                appointment.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
              }`}>
                {appointment.status === 'completed' ? 'Completed' : 'Upcoming'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProviderDashboard;