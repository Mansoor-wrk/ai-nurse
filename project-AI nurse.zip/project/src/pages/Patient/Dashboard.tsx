import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Calendar, Phone, FileText, Bell } from 'lucide-react';

const PatientDashboard: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-chathams-blue">{t('patient.title')}</h1>
      </div>

      {/* Welcome Card */}
      <div className="bg-gradient-to-r from-viking to-medium-purple rounded-xl shadow-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Welcome back, Ahmad!</h2>
        <p className="text-white/90">Your next call is scheduled for today at 2:30 PM with Dr. Sarah Johnson</p>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          {
            icon: Calendar,
            title: 'Next Appointment',
            value: 'Today 2:30 PM',
            subtitle: 'Dr. Sarah Johnson',
            color: 'bg-blue-500',
          },
          {
            icon: Phone,
            title: 'Last Call',
            value: '3 days ago',
            subtitle: '15 min duration',
            color: 'bg-green-500',
          },
          {
            icon: FileText,
            title: 'Care Plan',
            value: 'Updated',
            subtitle: '1 week ago',
            color: 'bg-medium-purple',
          },
          {
            icon: Bell,
            title: 'Notifications',
            value: '2 new',
            subtitle: 'Medication reminders',
            color: 'bg-orange-500',
          },
        ].map((item, index) => {
          const Icon = item.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">{item.title}</p>
                  <p className="text-xl font-bold text-gray-900 mt-1">{item.value}</p>
                  <p className="text-gray-500 text-sm mt-1">{item.subtitle}</p>
                </div>
                <div className={`${item.color} p-3 rounded-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {[
            { 
              date: 'Today',
              time: '10:00 AM',
              activity: 'Medication reminder sent',
              details: 'Metformin 500mg - Take with breakfast',
              status: 'info'
            },
            {
              date: 'Yesterday',
              time: '2:30 PM',
              activity: 'Call completed with Dr. Sarah Johnson',
              details: 'Duration: 15 minutes - Follow-up assessment',
              status: 'success'
            },
            {
              date: '3 days ago',
              time: '11:15 AM',
              activity: 'Care plan updated',
              details: 'Medication dosage adjusted',
              status: 'info'
            },
            {
              date: '1 week ago',
              time: '9:00 AM',
              activity: 'Lab results reviewed',
              details: 'Blood glucose levels improved',
              status: 'success'
            },
          ].map((activity, index) => (
            <div key={index} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
              <div className={`w-3 h-3 rounded-full mt-2 ${
                activity.status === 'success' ? 'bg-green-500' : 'bg-blue-500'
              }`}></div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-gray-900">{activity.activity}</span>
                  <span className="text-sm text-gray-500">•</span>
                  <span className="text-sm text-gray-500">{activity.date} at {activity.time}</span>
                </div>
                <p className="text-sm text-gray-600">{activity.details}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;