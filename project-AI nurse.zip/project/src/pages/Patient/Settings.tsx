import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { Settings as SettingsIcon, Save, User, Phone, Clock } from 'lucide-react';

const PatientSettings: React.FC = () => {
  const { user } = useAuth();
  const { t, isRTL } = useLanguage();
  
  const [settings, setSettings] = useState({
    full_name: user?.full_name || '',
    phone: user?.phone || '',
    email: user?.email || '',
    emergency_contact_1: '+966501234571',
    emergency_contact_2: '+966501234572',
    preferred_language: user?.preferred_language || 'en',
    preferred_voice: 'female',
    preferred_accent: 'neutral',
    suitable_call_time_start: '09:00',
    suitable_call_time_end: '17:00',
    do_not_call: false,
  });

  const [credentials, setCredentials] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleSettingsChange = (field: string, value: string | boolean) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleCredentialsChange = (field: string, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = () => {
    console.log('Saving patient settings:', settings);
    // Here you would typically make an API call to update the settings
  };

  const handleChangePassword = () => {
    if (credentials.newPassword !== credentials.confirmPassword) {
      alert('New passwords do not match');
      return;
    }
    console.log('Changing password');
    // Here you would typically make an API call to change the password
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <SettingsIcon className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.settings')}</h1>
      </div>

      {/* Call Preferences */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Phone className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Call Preferences</h2>
        </div>
        
        <div className="space-y-6">
          <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <input
              type="checkbox"
              id="do_not_call"
              checked={settings.do_not_call}
              onChange={(e) => handleSettingsChange('do_not_call', e.target.checked)}
              className="rounded border-gray-300 text-viking focus:ring-viking"
            />
            <label htmlFor="do_not_call" className="text-lg font-medium text-gray-900">
              {t('patient.doNotCall')}
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Call Time Start
              </label>
              <input
                type="time"
                value={settings.suitable_call_time_start}
                onChange={(e) => handleSettingsChange('suitable_call_time_start', e.target.value)}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                disabled={settings.do_not_call}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Call Time End
              </label>
              <input
                type="time"
                value={settings.suitable_call_time_end}
                onChange={(e) => handleSettingsChange('suitable_call_time_end', e.target.value)}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                disabled={settings.do_not_call}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Preferred Language
              </label>
              <select
                value={settings.preferred_language}
                onChange={(e) => handleSettingsChange('preferred_language', e.target.value)}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              >
                <option value="en">English</option>
                <option value="ar">العربية</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Preferred Voice
              </label>
              <select
                value={settings.preferred_voice}
                onChange={(e) => handleSettingsChange('preferred_voice', e.target.value)}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              >
                <option value="female">Female</option>
                <option value="male">Male</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Preferred Accent
              </label>
              <select
                value={settings.preferred_accent}
                onChange={(e) => handleSettingsChange('preferred_accent', e.target.value)}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              >
                <option value="neutral">Neutral</option>
                <option value="saudi">Saudi</option>
                <option value="egyptian">Egyptian</option>
                <option value="levantine">Levantine</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Personal Information */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <User className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Personal Information</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('common.name')}
            </label>
            <input
              type="text"
              value={settings.full_name}
              onChange={(e) => handleSettingsChange('full_name', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('common.phone')}
            </label>
            <input
              type="tel"
              value={settings.phone}
              onChange={(e) => handleSettingsChange('phone', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('common.email')}
            </label>
            <input
              type="email"
              value={settings.email}
              onChange={(e) => handleSettingsChange('email', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Emergency Contact 1
            </label>
            <input
              type="tel"
              value={settings.emergency_contact_1}
              onChange={(e) => handleSettingsChange('emergency_contact_1', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Emergency Contact 2
            </label>
            <input
              type="tel"
              value={settings.emergency_contact_2}
              onChange={(e) => handleSettingsChange('emergency_contact_2', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleSaveSettings}
            className={`flex items-center gap-2 px-6 py-3 bg-viking text-white rounded-lg hover:bg-viking/90 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Save className="w-5 h-5" />
            {t('common.save')}
          </button>
        </div>
      </div>

      {/* Change Password */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Change Password</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Current Password
            </label>
            <input
              type="password"
              value={credentials.currentPassword}
              onChange={(e) => handleCredentialsChange('currentPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              New Password
            </label>
            <input
              type="password"
              value={credentials.newPassword}
              onChange={(e) => handleCredentialsChange('newPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Confirm Password
            </label>
            <input
              type="password"
              value={credentials.confirmPassword}
              onChange={(e) => handleCredentialsChange('confirmPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleChangePassword}
            className={`flex items-center gap-2 px-6 py-3 bg-medium-purple text-white rounded-lg hover:bg-medium-purple/90 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Save className="w-5 h-5" />
            Change Password
          </button>
        </div>
      </div>

      {/* Assigned Provider Information */}
      <div className="bg-gradient-to-r from-viking/10 to-medium-purple/10 rounded-xl p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Assigned Provider</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Provider Name</label>
            <p className="mt-1 text-sm text-gray-900">Dr. Sarah Johnson</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Contact Phone</label>
            <p className="mt-1 text-sm text-gray-900">+966501234568</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <p className="mt-1 text-sm text-gray-900">sarah@telenurse.com</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Next Scheduled Call</label>
            <p className="mt-1 text-sm text-gray-900">Today at 2:30 PM</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientSettings;