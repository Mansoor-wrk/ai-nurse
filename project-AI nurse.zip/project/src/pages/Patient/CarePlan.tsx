import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { FileText, Calendar, Pill, Activity, Clock, User } from 'lucide-react';

const PatientCarePlan: React.FC = () => {
  const { t, isRTL } = useLanguage();

  // Mock patient data
  const patientData = {
    mrn: 'MRN001',
    full_name: 'Ahmad Al-Rashid',
    date_of_birth: '1985-05-15',
    medical_report: 'Patient presents with diabetes type 2. Blood glucose levels have been stable with current medication regimen. Patient shows good compliance with dietary recommendations.',
    clinical_history: 'Diagnosed with diabetes mellitus type 2 in 2020. Family history of diabetes (father). No history of diabetic complications. Regular follow-up with endocrinologist.',
    physical_exam: 'Vital signs stable. BMI: 28.5. Blood pressure: 130/80 mmHg. No signs of diabetic complications. Feet examination normal.',
    care_plan: 'Continue current medication regimen. Monitor blood glucose levels twice daily. Follow diabetic diet. Regular exercise 30 minutes daily. Monthly HbA1c monitoring.',
    medications: [
      { name: 'Metformin', dosage: '500', unit: 'mg', frequency: 'twice daily' },
      { name: 'Glipizide', dosage: '5', unit: 'mg', frequency: 'once daily' },
    ],
    icd10_codes: ['E11.9'],
    call_frequency: 'Every 1 week',
    next_call: '2024-01-20T14:30:00Z',
    assigned_provider: 'Dr. Sarah Johnson',
    what_to_assess: 'Blood glucose levels, medication compliance, dietary adherence, exercise routine',
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <FileText className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.myCareplan')}</h1>
      </div>

      {/* Patient Overview */}
      <div className="bg-gradient-to-r from-viking/10 to-medium-purple/10 rounded-xl p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Patient Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">MRN</label>
            <p className="mt-1 text-lg font-semibold text-gray-900">{patientData.mrn}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Full Name</label>
            <p className="mt-1 text-lg font-semibold text-gray-900">{patientData.full_name}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Date of Birth</label>
            <p className="mt-1 text-lg font-semibold text-gray-900">
              {new Date(patientData.date_of_birth).toLocaleDateString()}
            </p>
          </div>
        </div>
      </div>

      {/* Next Scheduled Call */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Calendar className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Next Scheduled Call</h2>
        </div>
        
        <div className="bg-viking/10 rounded-lg p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Date & Time</label>
              <p className="mt-1 text-lg font-semibold text-viking">
                {new Date(patientData.next_call).toLocaleDateString()} at{' '}
                {new Date(patientData.next_call).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Provider</label>
              <p className="mt-1 text-lg font-semibold text-gray-900">{patientData.assigned_provider}</p>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Call Frequency</label>
              <p className="mt-1 text-sm text-gray-600">{patientData.call_frequency}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Medical Information */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Activity className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Medical Information</h2>
        </div>
        
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-3">Medical Report (SOAP)</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 leading-relaxed">{patientData.medical_report}</p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-3">Clinical History</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 leading-relaxed">{patientData.clinical_history}</p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-3">Physical Examination</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 leading-relaxed">{patientData.physical_exam}</p>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-3">Care Plan</h3>
            <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-viking">
              <p className="text-gray-700 leading-relaxed">{patientData.care_plan}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Current Medications */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Pill className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Current Medications</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {patientData.medications.map((medication, index) => (
            <div key={index} className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h3 className="font-semibold text-gray-900 text-lg">{medication.name}</h3>
              <p className="text-gray-600 mt-1">
                <span className="font-medium">{medication.dosage}{medication.unit}</span> - {medication.frequency}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Assessment Focus */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Clock className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">What We'll Assess</h2>
        </div>
        
        <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
          <p className="text-gray-700 leading-relaxed">{patientData.what_to_assess}</p>
        </div>
      </div>

      {/* ICD-10 Codes */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center gap-3 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <User className="w-6 h-6 text-viking" />
          <h2 className="text-xl font-bold text-gray-900">Diagnosis Codes</h2>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {patientData.icd10_codes.map((code, index) => (
            <span key={index} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
              {code}
            </span>
          ))}
        </div>
      </div>

      {/* Important Notes */}
      <div className="bg-red-50 border border-red-200 rounded-xl p-6">
        <h2 className="text-xl font-bold text-red-800 mb-4">Important Notes</h2>
        <ul className="space-y-2 text-red-700">
          <li className="flex items-start gap-2">
            <span className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>Please take your medications as prescribed and at the same time each day.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>Monitor your blood glucose levels twice daily and keep a record.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>Contact your provider immediately if you experience any unusual symptoms.</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>Maintain regular exercise and follow your prescribed diet plan.</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default PatientCarePlan;