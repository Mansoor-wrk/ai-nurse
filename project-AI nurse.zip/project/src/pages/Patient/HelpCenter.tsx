import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { HelpCircle, Phone, MessageCircle, Mail, Clock, AlertTriangle } from 'lucide-react';

const PatientHelpCenter: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const handleCallProvider = () => {
    // In a real app, this would initiate a call
    alert('Calling your assigned provider: Dr. Sarah Johnson');
  };

  const handleCallAdmin = () => {
    // In a real app, this would initiate a call
    alert('Calling system administrator');
  };

  const handleWhatsAppEmergency = () => {
    // In a real app, this would open WhatsApp
    window.open('https://wa.me/966501234567', '_blank');
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <HelpCircle className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.helpCenter')}</h1>
      </div>

      {/* Emergency Contact */}
      <div className="bg-red-50 border-2 border-red-200 rounded-xl p-6">
        <div className={`flex items-center gap-3 mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <AlertTriangle className="w-6 h-6 text-red-600" />
          <h2 className="text-xl font-bold text-red-800">Emergency Contact</h2>
        </div>
        
        <p className="text-red-700 mb-4">
          If you are experiencing a medical emergency, please call emergency services immediately or go to the nearest hospital.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-red-100 p-4 rounded-lg">
            <h3 className="font-semibold text-red-800 mb-2">Emergency Services</h3>
            <p className="text-red-700 text-lg font-bold">997</p>
          </div>
          <div className="bg-red-100 p-4 rounded-lg">
            <h3 className="font-semibold text-red-800 mb-2">Emergency WhatsApp</h3>
            <button
              onClick={handleWhatsAppEmergency}
              className="text-red-700 text-lg font-bold hover:underline"
            >
              +966 50 123 4567
            </button>
          </div>
        </div>
      </div>

      {/* Quick Contact Options */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Contact</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button
            onClick={handleCallProvider}
            className={`flex items-center gap-4 p-6 bg-viking/10 hover:bg-viking/20 rounded-lg border-2 border-viking/20 hover:border-viking/40 transition-all ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <div className="p-3 bg-viking rounded-lg">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <div className={isRTL ? 'text-right' : 'text-left'}>
              <h3 className="font-semibold text-gray-900 text-lg">{t('patient.callProvider')}</h3>
              <p className="text-gray-600">Dr. Sarah Johnson</p>
              <p className="text-sm text-gray-500">Available 24/7</p>
            </div>
          </button>

          <button
            onClick={handleCallAdmin}
            className={`flex items-center gap-4 p-6 bg-medium-purple/10 hover:bg-medium-purple/20 rounded-lg border-2 border-medium-purple/20 hover:border-medium-purple/40 transition-all ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <div className="p-3 bg-medium-purple rounded-lg">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <div className={isRTL ? 'text-right' : 'text-left'}>
              <h3 className="font-semibold text-gray-900 text-lg">{t('patient.callAdmin')}</h3>
              <p className="text-gray-600">System Administrator</p>
              <p className="text-sm text-gray-500">Business hours</p>
            </div>
          </button>
        </div>
      </div>

      {/* Contact Information */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Contact Information</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Phone className="w-5 h-5 text-viking" />
              <div>
                <p className="font-medium text-gray-900">Provider Phone</p>
                <p className="text-gray-600">+966 50 123 4568</p>
              </div>
            </div>
            
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Mail className="w-5 h-5 text-viking" />
              <div>
                <p className="font-medium text-gray-900">Provider Email</p>
                <p className="text-gray-600">sarah@telenurse.com</p>
              </div>
            </div>
            
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <MessageCircle className="w-5 h-5 text-viking" />
              <div>
                <p className="font-medium text-gray-900">WhatsApp</p>
                <p className="text-gray-600">+966 50 123 4568</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Phone className="w-5 h-5 text-medium-purple" />
              <div>
                <p className="font-medium text-gray-900">Admin Phone</p>
                <p className="text-gray-600">+966 50 123 4567</p>
              </div>
            </div>
            
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Mail className="w-5 h-5 text-medium-purple" />
              <div>
                <p className="font-medium text-gray-900">Admin Email</p>
                <p className="text-gray-600">admin@telenurse.com</p>
              </div>
            </div>
            
            <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Clock className="w-5 h-5 text-medium-purple" />
              <div>
                <p className="font-medium text-gray-900">Business Hours</p>
                <p className="text-gray-600">8:00 AM - 6:00 PM</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
        
        <div className="space-y-4">
          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">How often will I receive calls?</h3>
            <p className="text-gray-600">
              Your call frequency is set based on your care plan. Currently, you are scheduled for calls every week. 
              You can view your next scheduled call on your dashboard.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">Can I change my call preferences?</h3>
            <p className="text-gray-600">
              Yes, you can update your call preferences including preferred times, language, and voice settings 
              in the Settings section of your account.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">What if I miss a scheduled call?</h3>
            <p className="text-gray-600">
              If you miss a scheduled call, your provider will attempt to reach you again. You can also 
              contact your provider directly using the contact information provided above.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">How do I update my medical information?</h3>
            <p className="text-gray-600">
              Your medical information is managed by your healthcare provider. If you need to update any 
              medical details, please contact your assigned provider directly.
            </p>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">Is my information secure?</h3>
            <p className="text-gray-600">
              Yes, all your medical information is encrypted and stored securely. We comply with all 
              healthcare privacy regulations to protect your personal health information.
            </p>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="bg-green-50 border border-green-200 rounded-xl p-6">
        <h2 className="text-xl font-bold text-green-800 mb-4">System Status</h2>
        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-green-700 font-medium">All systems operational</span>
        </div>
        <p className="text-green-600 text-sm mt-2">
          Last updated: {new Date().toLocaleString()}
        </p>
      </div>
    </div>
  );
};

export default PatientHelpCenter;