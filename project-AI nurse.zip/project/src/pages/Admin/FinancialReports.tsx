import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { DollarSign, Download, TrendingUp, Users, Phone, Calendar } from 'lucide-react';

const AdminFinancialReports: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const [costPerMinute, setCostPerMinute] = useState(2.5);
  const [dateRange, setDateRange] = useState({
    start: '2024-01-01',
    end: '2024-01-31',
  });

  // Mock data
  const reportData = {
    totalCallDuration: 1250, // minutes
    inboundCalls: 45,
    outboundCalls: 32,
    totalProviders: 24,
    totalPatients: 1247,
    totalRevenue: 1250 * costPerMinute,
    averageCallDuration: 16.2,
    successfulCalls: 68,
    failedCalls: 9,
  };

  const monthlyData = [
    { month: 'Jan', revenue: 3200, calls: 128, duration: 1280 },
    { month: 'Feb', revenue: 2800, calls: 112, duration: 1120 },
    { month: 'Mar', revenue: 3600, calls: 144, duration: 1440 },
    { month: 'Apr', revenue: 3100, calls: 124, duration: 1240 },
    { month: 'May', revenue: 3400, calls: 136, duration: 1360 },
    { month: 'Jun', revenue: 3750, calls: 150, duration: 1500 },
  ];

  const handleExportExcel = () => {
    console.log('Exporting financial report to Excel');
  };

  const handleUpdateCostPerMinute = () => {
    console.log('Updating cost per minute to:', costPerMinute);
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <DollarSign className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.financialReports')}</h1>
      </div>

      {/* Settings */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Settings</h2>
        <div className={`flex items-center gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cost Per Minute ($)
            </label>
            <input
              type="number"
              step="0.01"
              value={costPerMinute}
              onChange={(e) => setCostPerMinute(parseFloat(e.target.value))}
              className={`w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={handleUpdateCostPerMinute}
              className="px-4 py-2 bg-viking text-white rounded-lg hover:bg-viking/90"
            >
              Update
            </button>
          </div>
        </div>
      </div>

      {/* Date Range Filter */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <h2 className="text-xl font-bold text-gray-900">Financial Report</h2>
          <button
            onClick={handleExportExcel}
            className={`flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Download className="w-4 h-4" />
            Export Excel
          </button>
        </div>
        
        <div className={`flex items-center gap-4 mb-6 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Start Date
            </label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className={`px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              End Date
            </label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className={`px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-6 text-white">
            <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div>
                <p className="text-green-100 text-sm">Total Revenue</p>
                <p className="text-2xl font-bold">${reportData.totalRevenue.toFixed(2)}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-6 text-white">
            <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div>
                <p className="text-blue-100 text-sm">Total Call Duration</p>
                <p className="text-2xl font-bold">{reportData.totalCallDuration} min</p>
              </div>
              <Phone className="w-8 h-8 text-blue-200" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-viking to-medium-purple rounded-lg p-6 text-white">
            <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div>
                <p className="text-white/80 text-sm">Total Users</p>
                <p className="text-2xl font-bold">{reportData.totalProviders + reportData.totalPatients}</p>
              </div>
              <Users className="w-8 h-8 text-white/60" />
            </div>
          </div>

          <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-lg p-6 text-white">
            <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div>
                <p className="text-orange-100 text-sm">Avg Call Duration</p>
                <p className="text-2xl font-bold">{reportData.averageCallDuration} min</p>
              </div>
              <Calendar className="w-8 h-8 text-orange-200" />
            </div>
          </div>
        </div>

        {/* Detailed Breakdown */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Call Statistics</h3>
            <div className="space-y-3">
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Inbound Calls</span>
                <span className="font-medium text-gray-900">{reportData.inboundCalls}</span>
              </div>
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Outbound Calls</span>
                <span className="font-medium text-gray-900">{reportData.outboundCalls}</span>
              </div>
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Successful Calls</span>
                <span className="font-medium text-green-600">{reportData.successfulCalls}</span>
              </div>
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Failed Calls</span>
                <span className="font-medium text-red-600">{reportData.failedCalls}</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">User Statistics</h3>
            <div className="space-y-3">
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Total Providers</span>
                <span className="font-medium text-gray-900">{reportData.totalProviders}</span>
              </div>
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Total Patients</span>
                <span className="font-medium text-gray-900">{reportData.totalPatients}</span>
              </div>
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Cost Per Minute</span>
                <span className="font-medium text-gray-900">${costPerMinute}</span>
              </div>
              <div className={`flex items-center justify-between p-3 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="text-gray-700">Revenue Per Call</span>
                <span className="font-medium text-gray-900">${(reportData.averageCallDuration * costPerMinute).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Monthly Trend */}
        <div className="mt-8">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Monthly Trends</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className={`px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider ${isRTL ? 'text-right' : 'text-left'}`}>
                    Month
                  </th>
                  <th className={`px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider ${isRTL ? 'text-right' : 'text-left'}`}>
                    Revenue
                  </th>
                  <th className={`px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider ${isRTL ? 'text-right' : 'text-left'}`}>
                    Total Calls
                  </th>
                  <th className={`px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider ${isRTL ? 'text-right' : 'text-left'}`}>
                    Duration (min)
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {monthlyData.map((month, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {month.month}
                    </td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
                      ${month.revenue}
                    </td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {month.calls}
                    </td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm text-gray-900 ${isRTL ? 'text-right' : 'text-left'}`}>
                      {month.duration}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminFinancialReports;