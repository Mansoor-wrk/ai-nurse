import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { Save, Upload, Settings as SettingsIcon } from 'lucide-react';

const AdminSettings: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { systemSettings, updateSystemSettings } = useAuth();
  const [settings, setSettings] = useState({
    systemName: systemSettings.systemName,
    systemSlogan: systemSettings.systemSlogan,
    headerLogoUrl: systemSettings.headerLogoUrl || '',
    portalLogoUrl: systemSettings.portalLogoUrl || '',
    adminEmail: systemSettings.adminEmail || '',
    adminPhone: systemSettings.adminPhone || '',
    costPerMinute: systemSettings.costPerMinute,
  });

  const [credentials, setCredentials] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleSettingsChange = (field: string, value: string | number) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleCredentialsChange = (field: string, value: string) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveSettings = () => {
    // Save settings logic
    updateSystemSettings(settings);
    alert('Settings saved successfully!');
    console.log('Saving settings:', settings);
  };

  const handleChangePassword = () => {
    // Change password logic
    console.log('Changing password');
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <SettingsIcon className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.settings')}</h1>
      </div>

      {/* System Settings */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">System Settings</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              System Name
            </label>
            <input
              type="text"
              value={settings.systemName}
              onChange={(e) => handleSettingsChange('systemName', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Admin Email
            </label>
            <input
              type="email"
              value={settings.adminEmail}
              onChange={(e) => handleSettingsChange('adminEmail', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            System Slogan / Description
          </label>
          <textarea
            value={settings.systemSlogan}
            onChange={(e) => handleSettingsChange('systemSlogan', e.target.value)}
            rows={3}
            placeholder="Enter the system description that appears on the landing page"
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
          />
          <p className="text-sm text-gray-500 mt-1">
            This text will be displayed on the landing page below the system title.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Admin Phone
            </label>
            <input
              type="tel"
              value={settings.adminPhone}
              onChange={(e) => handleSettingsChange('adminPhone', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cost Per Minute ($)
            </label>
            <input
              type="number"
              step="0.01"
              value={settings.costPerMinute}
              onChange={(e) => handleSettingsChange('costPerMinute', parseFloat(e.target.value))}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Header Logo
            </label>
            <div className="flex items-center gap-3">
              <input
                type="url"
                value={settings.headerLogoUrl}
                onChange={(e) => handleSettingsChange('headerLogoUrl', e.target.value)}
                placeholder="Logo URL"
                className={`flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
              <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Upload
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Portal Logo
            </label>
            <div className="flex items-center gap-3">
              <input
                type="url"
                value={settings.portalLogoUrl}
                onChange={(e) => handleSettingsChange('portalLogoUrl', e.target.value)}
                placeholder="Logo URL"
                className={`flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
              <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Upload
              </button>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleSaveSettings}
            className={`flex items-center gap-2 px-6 py-3 bg-viking text-white rounded-lg hover:bg-viking/90 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Save className="w-5 h-5" />
            {t('common.save')}
          </button>
        </div>
      </div>

      {/* Change Password */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Change Password</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Current Password
            </label>
            <input
              type="password"
              value={credentials.currentPassword}
              onChange={(e) => handleCredentialsChange('currentPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              New Password
            </label>
            <input
              type="password"
              value={credentials.newPassword}
              onChange={(e) => handleCredentialsChange('newPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Confirm Password
            </label>
            <input
              type="password"
              value={credentials.confirmPassword}
              onChange={(e) => handleCredentialsChange('confirmPassword', e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={handleChangePassword}
            className={`flex items-center gap-2 px-6 py-3 bg-medium-purple text-white rounded-lg hover:bg-medium-purple/90 ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Save className="w-5 h-5" />
            Change Password
          </button>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;