import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Download, FileText, Users, UserCheck, Phone, Calendar } from 'lucide-react';

const AdminExportData: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const [exportOptions, setExportOptions] = useState({
    providers: true,
    patients: true,
    callLogs: true,
    financialReports: false,
  });
  
  const [dateRange, setDateRange] = useState({
    start: '2024-01-01',
    end: '2024-01-31',
  });

  const [format, setFormat] = useState('excel');

  const exportItems = [
    {
      key: 'providers',
      icon: UserCheck,
      title: 'Providers Data',
      description: 'Export all provider information including contact details and patient assignments',
      count: '24 providers',
    },
    {
      key: 'patients',
      icon: Users,
      title: 'Patients Data',
      description: 'Export patient records, medical information, and care plans',
      count: '1,247 patients',
    },
    {
      key: 'callLogs',
      icon: Phone,
      title: 'Call Logs',
      description: 'Export call history, transcriptions, and call outcomes',
      count: '3,456 calls',
    },
    {
      key: 'financialReports',
      icon: Calendar,
      title: 'Financial Reports',
      description: 'Export revenue data, call durations, and billing information',
      count: 'Last 6 months',
    },
  ];

  const handleExportOptionChange = (key: string, checked: boolean) => {
    setExportOptions(prev => ({ ...prev, [key]: checked }));
  };

  const handleExport = () => {
    const selectedItems = Object.entries(exportOptions)
      .filter(([_, selected]) => selected)
      .map(([key, _]) => key);
    
    console.log('Exporting:', {
      items: selectedItems,
      format,
      dateRange,
    });
    
    // Simulate export process
    alert(`Exporting ${selectedItems.join(', ')} as ${format.toUpperCase()} format`);
  };

  const selectedCount = Object.values(exportOptions).filter(Boolean).length;

  return (
    <div className="space-y-6">
      <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
        <Download className="w-8 h-8 text-viking" />
        <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.exportData')}</h1>
      </div>

      {/* Export Options */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Select Data to Export</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {exportItems.map((item) => {
            const Icon = item.icon;
            const isSelected = exportOptions[item.key as keyof typeof exportOptions];
            
            return (
              <div
                key={item.key}
                className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                  isSelected 
                    ? 'border-viking bg-viking/5' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => handleExportOptionChange(item.key, !isSelected)}
              >
                <div className={`flex items-start gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className={`p-2 rounded-lg ${isSelected ? 'bg-viking text-white' : 'bg-gray-100 text-gray-600'}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <h3 className="font-medium text-gray-900">{item.title}</h3>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => handleExportOptionChange(item.key, e.target.checked)}
                        className="rounded border-gray-300 text-viking focus:ring-viking"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                      {item.count}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Export Settings */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Export Settings</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Export Format
            </label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            >
              <option value="excel">Excel (.xlsx)</option>
              <option value="csv">CSV (.csv)</option>
              <option value="pdf">PDF (.pdf)</option>
              <option value="json">JSON (.json)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Start Date
            </label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              End Date
            </label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
            />
          </div>
        </div>
      </div>

      {/* Export Summary */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Export Summary</h2>
        
        <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
          <div>
            <p className="text-gray-600">
              {selectedCount} data type{selectedCount !== 1 ? 's' : ''} selected for export
            </p>
            <p className="text-sm text-gray-500 mt-1">
              Date range: {new Date(dateRange.start).toLocaleDateString()} - {new Date(dateRange.end).toLocaleDateString()}
            </p>
            <p className="text-sm text-gray-500">
              Format: {format.toUpperCase()}
            </p>
          </div>
          
          <button
            onClick={handleExport}
            disabled={selectedCount === 0}
            className={`flex items-center gap-2 px-6 py-3 bg-viking text-white rounded-lg hover:bg-viking/90 disabled:opacity-50 disabled:cursor-not-allowed ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            <Download className="w-5 h-5" />
            Export Data
          </button>
        </div>
      </div>

      {/* Recent Exports */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Exports</h2>
        
        <div className="space-y-3">
          {[
            {
              date: '2024-01-15',
              time: '10:30 AM',
              type: 'Patients Data',
              format: 'Excel',
              size: '2.4 MB',
              status: 'completed',
            },
            {
              date: '2024-01-14',
              time: '3:45 PM',
              type: 'Call Logs',
              format: 'PDF',
              size: '1.8 MB',
              status: 'completed',
            },
            {
              date: '2024-01-13',
              time: '9:15 AM',
              type: 'Financial Reports',
              format: 'Excel',
              size: '856 KB',
              status: 'completed',
            },
          ].map((export_, index) => (
            <div key={index} className={`flex items-center justify-between p-4 bg-gray-50 rounded-lg ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <FileText className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="font-medium text-gray-900">{export_.type}</p>
                  <p className="text-sm text-gray-500">
                    {new Date(export_.date).toLocaleDateString()} at {export_.time} • {export_.format} • {export_.size}
                  </p>
                </div>
              </div>
              <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">
                  {export_.status}
                </span>
                <button className="p-2 text-gray-400 hover:text-gray-600 rounded">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminExportData;