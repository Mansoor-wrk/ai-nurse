import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Save, 
  Upload, 
  FileText, 
  Trash2, 
  Download, 
  Brain,
  Settings,
  Eye,
  EyeOff,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Copy,
  Zap,
  Database,
  Shield,
  Clock,
  BarChart3
} from 'lucide-react';

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  uploadDate: Date;
  type: string;
  status: 'processing' | 'ready' | 'error';
  pages?: number;
}

interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  content: string;
  category: 'medical' | 'general' | 'emergency' | 'custom';
}

const AdminMainPrompt: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const { systemSettings, updateSystemSettings } = useAuth();
  const [hasChanges, setHasChanges] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [activeTab, setActiveTab] = useState<'prompt' | 'parameters' | 'knowledge' | 'templates'>('prompt');
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([
    {
      id: '1',
      name: 'medical-guidelines-2024.pdf',
      size: 2456789,
      uploadDate: new Date('2024-01-15'),
      type: 'application/pdf',
      status: 'ready',
      pages: 245
    },
    {
      id: '2',
      name: 'treatment-protocols.pdf',
      size: 1234567,
      uploadDate: new Date('2024-01-10'),
      type: 'application/pdf',
      status: 'ready',
      pages: 156
    },
    {
      id: '3',
      name: 'emergency-procedures.pdf',
      size: 987654,
      uploadDate: new Date('2024-01-20'),
      type: 'application/pdf',
      status: 'processing'
    }
  ]);
  
  const [isDragOver, setIsDragOver] = useState(false);

  const [formData, setFormData] = useState({
    systemPrompt: `You are an advanced AI medical assistant designed to support healthcare providers in delivering exceptional patient care. Your role encompasses multiple critical functions:

## Core Responsibilities:
1. **Clinical Decision Support**: Provide evidence-based medical information and diagnostic considerations
2. **Treatment Guidance**: Suggest appropriate treatment options based on current medical guidelines
3. **Patient Safety**: Always prioritize patient safety and highlight potential risks
4. **Professional Standards**: Maintain the highest standards of medical ethics and professionalism

## Interaction Guidelines:
- Always emphasize that AI assistance supplements, never replaces, professional medical judgment
- Provide clear, concise, and actionable information
- Include relevant medical references when appropriate
- Flag urgent situations that require immediate attention
- Respect patient confidentiality and privacy at all times

## Communication Style:
- Use clear, professional medical terminology
- Provide structured responses with clear headings
- Include differential diagnoses when relevant
- Suggest follow-up actions and monitoring requirements

## Safety Protocols:
- Never provide definitive diagnoses without proper clinical evaluation
- Always recommend consulting with specialists when appropriate
- Highlight contraindications and potential adverse effects
- Emphasize the importance of patient history and physical examination

Remember: You are a powerful tool to enhance healthcare delivery, but clinical judgment and patient care remain the responsibility of licensed healthcare professionals.`,
    temperature: 0.3,
    maxTokens: 2000,
    topP: 0.9,
    frequencyPenalty: 0.0,
    presencePenalty: 0.0,
    systemRole: 'medical_assistant',
    responseFormat: 'structured',
    safetyLevel: 'high'
  });

  const promptTemplates: PromptTemplate[] = [
    {
      id: '1',
      name: 'General Medical Assistant',
      description: 'Balanced approach for general medical consultations',
      category: 'medical',
      content: 'You are a medical AI assistant providing general healthcare support...'
    },
    {
      id: '2',
      name: 'Emergency Response',
      description: 'Optimized for urgent medical situations',
      category: 'emergency',
      content: 'You are an emergency medical AI assistant. Prioritize immediate life-threatening conditions...'
    },
    {
      id: '3',
      name: 'Specialist Consultation',
      description: 'For specialized medical domains',
      category: 'medical',
      content: 'You are a specialist medical AI assistant with deep expertise in specific medical fields...'
    },
    {
      id: '4',
      name: 'Patient Education',
      description: 'Focused on patient communication and education',
      category: 'general',
      content: 'You are a patient education AI assistant. Use simple, clear language to explain medical concepts...'
    }
  ];

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      updateSystemSettings({
        temperature: formData.temperature,
        max_tokens: formData.maxTokens
      });
      
      setHasChanges(false);
      setLastSaved(new Date());
      console.log('Saving main prompt settings:', formData);
    } catch (error) {
      console.error('Error saving settings:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleTemplateApply = (template: PromptTemplate) => {
    setFormData(prev => ({ ...prev, systemPrompt: template.content }));
    setHasChanges(true);
  };

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(formData.systemPrompt);
    // You could add a toast notification here
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileUpload = (files: FileList | null) => {
    if (!files) return;

    const newFiles: UploadedFile[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      if (file.type !== 'application/pdf') {
        alert(`${file.name} is not a PDF file. Only PDF files are allowed.`);
        continue;
      }

      const newFile: UploadedFile = {
        id: Date.now().toString() + i,
        name: file.name,
        size: file.size,
        uploadDate: new Date(),
        type: file.type,
        status: 'processing'
      };
      
      newFiles.push(newFile);
    }

    if (newFiles.length > 0) {
      setUploadedFiles(prev => [...prev, ...newFiles]);
      setHasChanges(true);
      
      // Simulate processing
      newFiles.forEach(file => {
        setTimeout(() => {
          setUploadedFiles(prev => prev.map(f => 
            f.id === file.id ? { ...f, status: 'ready', pages: Math.floor(Math.random() * 200) + 50 } : f
          ));
        }, 2000 + Math.random() * 3000);
      });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleDeleteFile = (fileId: string) => {
    if (confirm('Are you sure you want to delete this file?')) {
      setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
      setHasChanges(true);
    }
  };

  const getStatusIcon = (status: UploadedFile['status']) => {
    switch (status) {
      case 'processing':
        return <RefreshCw className="w-4 h-4 text-yellow-500 animate-spin" />;
      case 'ready':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
    }
  };

  const tabs = [
    { id: 'prompt', label: 'System Prompt', icon: Brain },
    { id: 'parameters', label: 'Model Parameters', icon: Settings },
    { id: 'knowledge', label: 'Knowledge Base', icon: Database },
    { id: 'templates', label: 'Templates', icon: FileText }
  ];

  return (
    <div className={`space-y-6 ${isRTL ? 'rtl' : 'ltr'}`}>
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Brain className="w-8 h-8 text-viking" />
          <div>
            <h1 className="text-3xl font-bold text-chathams-blue">AI System Configuration</h1>
            <p className="text-gray-600">Configure the AI assistant's behavior and knowledge base</p>
          </div>
        </div>
        
        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
          {lastSaved && (
            <div className={`flex items-center gap-2 text-sm text-gray-500 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Clock className="w-4 h-4" />
              <span>Last saved: {lastSaved.toLocaleTimeString()}</span>
            </div>
          )}
          <button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            className={`flex items-center gap-2 px-6 py-3 bg-viking text-white rounded-lg hover:bg-viking/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all ${isRTL ? 'flex-row-reverse' : ''}`}
          >
            {isSaving ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <Save className="w-5 h-5" />
            )}
            {isSaving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>

      {/* Status Bar */}
      {hasChanges && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <AlertCircle className="w-5 h-5 text-yellow-600" />
            <span className="text-yellow-800">You have unsaved changes</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className={`flex ${isRTL ? 'flex-row-reverse' : ''}`}>
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors ${
                    activeTab === tab.id
                      ? 'text-viking border-b-2 border-viking bg-viking/5'
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  } ${isRTL ? 'flex-row-reverse' : ''}`}
                >
                  <Icon className="w-5 h-5" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="p-6">
          {/* System Prompt Tab */}
          {activeTab === 'prompt' && (
            <div className="space-y-6">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h2 className="text-xl font-semibold text-gray-900">System Prompt Configuration</h2>
                <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <button
                    onClick={handleCopyPrompt}
                    className={`flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors ${isRTL ? 'flex-row-reverse' : ''}`}
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </button>
                  <button
                    onClick={() => setIsPreviewMode(!isPreviewMode)}
                    className={`flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors ${isRTL ? 'flex-row-reverse' : ''}`}
                  >
                    {isPreviewMode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {isPreviewMode ? 'Edit' : 'Preview'}
                  </button>
                </div>
              </div>

              {isPreviewMode ? (
                <div className="bg-gray-50 p-6 rounded-lg border">
                  <div className="prose max-w-none">
                    <pre className="whitespace-pre-wrap text-sm text-gray-800 font-mono">
                      {formData.systemPrompt}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <textarea
                    value={formData.systemPrompt}
                    onChange={(e) => handleInputChange('systemPrompt', e.target.value)}
                    className={`w-full h-96 p-4 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-viking focus:border-viking font-mono text-sm ${isRTL ? 'text-right' : 'text-left'}`}
                    placeholder="Enter your system prompt here..."
                  />
                  <div className={`flex items-center justify-between text-sm text-gray-500 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <span>{formData.systemPrompt.length} characters</span>
                    <span>~{Math.ceil(formData.systemPrompt.length / 4)} tokens</span>
                  </div>
                </div>
              )}

              {/* Quick Actions */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Shield className="w-5 h-5 text-blue-600" />
                    <h3 className="font-medium text-blue-900">Safety Level</h3>
                  </div>
                  <select
                    value={formData.safetyLevel}
                    onChange={(e) => handleInputChange('safetyLevel', e.target.value)}
                    className={`w-full px-3 py-2 border border-blue-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${isRTL ? 'text-right' : ''}`}
                  >
                    <option value="low">Low - More creative responses</option>
                    <option value="medium">Medium - Balanced approach</option>
                    <option value="high">High - Conservative and safe</option>
                  </select>
                </div>

                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <Zap className="w-5 h-5 text-green-600" />
                    <h3 className="font-medium text-green-900">Response Format</h3>
                  </div>
                  <select
                    value={formData.responseFormat}
                    onChange={(e) => handleInputChange('responseFormat', e.target.value)}
                    className={`w-full px-3 py-2 border border-green-300 rounded focus:ring-2 focus:ring-green-500 focus:border-green-500 ${isRTL ? 'text-right' : ''}`}
                  >
                    <option value="structured">Structured - Clear sections</option>
                    <option value="conversational">Conversational - Natural flow</option>
                    <option value="clinical">Clinical - Medical format</option>
                  </select>
                </div>

                <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                  <div className={`flex items-center gap-2 mb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <BarChart3 className="w-5 h-5 text-purple-600" />
                    <h3 className="font-medium text-purple-900">System Role</h3>
                  </div>
                  <select
                    value={formData.systemRole}
                    onChange={(e) => handleInputChange('systemRole', e.target.value)}
                    className={`w-full px-3 py-2 border border-purple-300 rounded focus:ring-2 focus:ring-purple-500 focus:border-purple-500 ${isRTL ? 'text-right' : ''}`}
                  >
                    <option value="medical_assistant">Medical Assistant</option>
                    <option value="clinical_advisor">Clinical Advisor</option>
                    <option value="patient_educator">Patient Educator</option>
                    <option value="emergency_responder">Emergency Responder</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Model Parameters Tab */}
          {activeTab === 'parameters' && (
            <div className="space-y-6">
              <h2 className="text-xl font-semibold text-gray-900">Model Parameters</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Temperature: {formData.temperature}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={formData.temperature}
                    onChange={(e) => handleInputChange('temperature', parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Focused</span>
                    <span>Creative</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    Controls randomness in responses. Lower values are more focused and deterministic.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Max Tokens: {formData.maxTokens}
                  </label>
                  <input
                    type="range"
                    min="100"
                    max="4000"
                    step="100"
                    value={formData.maxTokens}
                    onChange={(e) => handleInputChange('maxTokens', parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Short</span>
                    <span>Long</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    Maximum length of the AI response. Higher values allow longer responses.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Top P: {formData.topP}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={formData.topP}
                    onChange={(e) => handleInputChange('topP', parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Narrow</span>
                    <span>Diverse</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    Controls diversity via nucleus sampling. Lower values focus on likely tokens.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Frequency Penalty: {formData.frequencyPenalty}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={formData.frequencyPenalty}
                    onChange={(e) => handleInputChange('frequencyPenalty', parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <p className="text-xs text-gray-500">
                    Reduces repetition of frequent tokens. Higher values decrease repetition.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Presence Penalty: {formData.presencePenalty}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={formData.presencePenalty}
                    onChange={(e) => handleInputChange('presencePenalty', parseFloat(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <p className="text-xs text-gray-500">
                    Encourages talking about new topics. Higher values increase topic diversity.
                  </p>
                </div>
              </div>

              {/* Parameter Presets */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Parameter Presets</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <button
                    onClick={() => {
                      setFormData(prev => ({ ...prev, temperature: 0.1, topP: 0.1, frequencyPenalty: 0.0, presencePenalty: 0.0 }));
                      setHasChanges(true);
                    }}
                    className="p-4 text-left border border-gray-200 rounded-lg hover:border-viking hover:bg-viking/5 transition-colors"
                  >
                    <h4 className="font-medium text-gray-900">Precise</h4>
                    <p className="text-sm text-gray-600">Focused, deterministic responses</p>
                  </button>
                  <button
                    onClick={() => {
                      setFormData(prev => ({ ...prev, temperature: 0.7, topP: 0.9, frequencyPenalty: 0.0, presencePenalty: 0.0 }));
                      setHasChanges(true);
                    }}
                    className="p-4 text-left border border-gray-200 rounded-lg hover:border-viking hover:bg-viking/5 transition-colors"
                  >
                    <h4 className="font-medium text-gray-900">Balanced</h4>
                    <p className="text-sm text-gray-600">Good balance of creativity and focus</p>
                  </button>
                  <button
                    onClick={() => {
                      setFormData(prev => ({ ...prev, temperature: 1.2, topP: 0.95, frequencyPenalty: 0.5, presencePenalty: 0.5 }));
                      setHasChanges(true);
                    }}
                    className="p-4 text-left border border-gray-200 rounded-lg hover:border-viking hover:bg-viking/5 transition-colors"
                  >
                    <h4 className="font-medium text-gray-900">Creative</h4>
                    <p className="text-sm text-gray-600">More diverse and creative responses</p>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Knowledge Base Tab */}
          {activeTab === 'knowledge' && (
            <div className="space-y-6">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h2 className="text-xl font-semibold text-gray-900">Medical Knowledge Base</h2>
                <div className={`flex items-center gap-2 text-sm text-gray-600 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <Database className="w-4 h-4" />
                  <span>{uploadedFiles.length} documents • {uploadedFiles.reduce((acc, file) => acc + file.size, 0) > 0 ? formatFileSize(uploadedFiles.reduce((acc, file) => acc + file.size, 0)) : '0 Bytes'}</span>
                </div>
              </div>
              
              {/* Upload Area */}
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-all ${
                  isDragOver
                    ? 'border-viking bg-viking/5 scale-105'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                <Upload className={`mx-auto h-12 w-12 mb-4 transition-colors ${isDragOver ? 'text-viking' : 'text-gray-400'}`} />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  Upload Medical Documents
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  Drag and drop PDF files here, or click to browse
                </p>
                <input
                  type="file"
                  multiple
                  accept=".pdf"
                  onChange={(e) => handleFileUpload(e.target.files)}
                  className="hidden"
                  id="pdf-upload"
                />
                <label
                  htmlFor="pdf-upload"
                  className={`inline-flex items-center px-6 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-viking hover:bg-viking/90 cursor-pointer transition-all ${isRTL ? 'flex-row-reverse' : ''}`}
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Select Files
                </label>
              </div>

              {/* File List */}
              {uploadedFiles.length > 0 && (
                <div>
                  <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <h3 className="text-lg font-medium text-gray-900">
                      Uploaded Documents ({uploadedFiles.length})
                    </h3>
                  </div>
                  <div className="space-y-3">
                    {uploadedFiles.map((file) => (
                      <div
                        key={file.id}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:bg-gray-100 transition-colors"
                      >
                        <div className={`flex items-center gap-4 flex-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <FileText className="w-8 h-8 text-red-500 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <div className={`flex items-center gap-2 mb-1 ${isRTL ? 'flex-row-reverse' : ''}`}>
                              <p className="font-medium text-gray-900 truncate">{file.name}</p>
                              {getStatusIcon(file.status)}
                            </div>
                            <div className={`flex items-center gap-4 text-sm text-gray-500 ${isRTL ? 'flex-row-reverse' : ''}`}>
                              <span>{formatFileSize(file.size)}</span>
                              <span>{file.uploadDate.toLocaleDateString()}</span>
                              {file.pages && <span>{file.pages} pages</span>}
                              <span className={`px-2 py-1 rounded-full text-xs ${
                                file.status === 'ready' ? 'bg-green-100 text-green-800' :
                                file.status === 'processing' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'
                              }`}>
                                {file.status}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <button
                            onClick={() => {/* Download logic */}}
                            className="p-2 text-gray-400 hover:text-viking transition-colors"
                            title="Download"
                            disabled={file.status !== 'ready'}
                          >
                            <Download className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteFile(file.id)}
                            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Templates Tab */}
          {activeTab === 'templates' && (
            <div className="space-y-6">
              <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <h2 className="text-xl font-semibold text-gray-900">Prompt Templates</h2>
                <button className={`flex items-center gap-2 px-4 py-2 bg-viking text-white rounded-lg hover:bg-viking/90 transition-colors ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <FileText className="w-4 h-4" />
                  Create Template
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {promptTemplates.map((template) => (
                  <div key={template.id} className="border border-gray-200 rounded-lg p-6 hover:border-viking hover:shadow-md transition-all">
                    <div className={`flex items-start justify-between mb-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                      <div>
                        <h3 className="font-semibold text-gray-900">{template.name}</h3>
                        <span className={`inline-block px-2 py-1 text-xs rounded-full mt-1 ${
                          template.category === 'medical' ? 'bg-blue-100 text-blue-800' :
                          template.category === 'emergency' ? 'bg-red-100 text-red-800' :
                          template.category === 'general' ? 'bg-green-100 text-green-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {template.category}
                        </span>
                      </div>
                      <button
                        onClick={() => handleTemplateApply(template)}
                        className="px-3 py-1 text-sm text-viking hover:text-viking/80 hover:bg-viking/10 rounded transition-colors"
                      >
                        Apply
                      </button>
                    </div>
                    <p className="text-gray-600 text-sm mb-4">{template.description}</p>
                    <div className="bg-gray-50 p-3 rounded text-xs text-gray-700 font-mono">
                      {template.content.substring(0, 100)}...
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminMainPrompt;