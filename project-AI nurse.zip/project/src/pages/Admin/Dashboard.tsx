import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Users, UserCheck, Phone, DollarSign } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { t } = useLanguage();

  const stats = [
    {
      icon: UserCheck,
      title: 'Total Providers',
      value: '24',
      change: '+2 this month',
      color: 'bg-blue-500',
    },
    {
      icon: Users,
      title: 'Total Patients',
      value: '1,247',
      change: '+48 this month',
      color: 'bg-green-500',
    },
    {
      icon: Phone,
      title: 'Total Calls Today',
      value: '89',
      change: '+12% from yesterday',
      color: 'bg-viking',
    },
    {
      icon: DollarSign,
      title: 'Monthly Revenue',
      value: '$12,450',
      change: '+8.2% from last month',
      color: 'bg-medium-purple',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-chathams-blue">{t('admin.title')}</h1>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">{stat.title}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  <p className="text-green-600 text-sm mt-1">{stat.change}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
        <div className="space-y-4">
          {[
            { time: '2 min ago', action: 'New patient registration', user: 'Ahmed Al-Rashid' },
            { time: '15 min ago', action: 'Call completed', user: 'Dr. Sarah Johnson → Fatima Hassan' },
            { time: '1 hour ago', action: 'Care plan updated', user: 'Dr. Michael Brown' },
            { time: '2 hours ago', action: 'Provider login', user: 'Dr. Sarah Johnson' },
          ].map((activity, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">{activity.action}</p>
                <p className="text-sm text-gray-600">{activity.user}</p>
              </div>
              <span className="text-sm text-gray-500">{activity.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;