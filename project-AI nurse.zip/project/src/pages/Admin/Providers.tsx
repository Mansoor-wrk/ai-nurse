import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { UserCheck, Plus, Edit, Trash2, Shield, ShieldOff } from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import Modal from '../../components/Common/Modal';
import { Provider } from '../../types';

const AdminProviders: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const [providers, setProviders] = useState<Provider[]>([
    {
      id: '1',
      username: 'dr_sarah',
      email: 'sarah@telenurse.com',
      phone: '+966501234568',
      role: 'provider',
      full_name: 'Dr. Sarah Johnson',
      is_active: true,
      preferred_language: 'en',
      created_at: '2024-01-15T10:00:00Z',
      updated_at: '2024-01-15T10:00:00Z',
      national_id: '1234567890',
      patients_count: 15,
    },
    {
      id: '2',
      username: 'dr_ahmed',
      email: 'ahmed@telenurse.com',
      phone: '+966501234569',
      role: 'provider',
      full_name: 'Dr. Ahmed Al-Rashid',
      is_active: true,
      preferred_language: 'ar',
      created_at: '2024-01-10T09:00:00Z',
      updated_at: '2024-01-10T09:00:00Z',
      national_id: '0987654321',
      patients_count: 22,
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProvider, setEditingProvider] = useState<Provider | null>(null);
  const [formData, setFormData] = useState({
    full_name: '',
    username: '',
    email: '',
    phone: '',
    national_id: '',
    password: '',
    is_active: true,
  });

  const columns = [
    {
      key: 'full_name',
      label: 'Name',
      sortable: true,
    },
    {
      key: 'username',
      label: 'Username',
      sortable: true,
    },
    {
      key: 'email',
      label: 'Email',
      sortable: true,
    },
    {
      key: 'phone',
      label: 'Phone',
    },
    {
      key: 'patients_count',
      label: 'Patients',
      render: (value: number) => (
        <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
          {value}
        </span>
      ),
    },
    {
      key: 'is_active',
      label: 'Status',
      render: (value: boolean) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {value ? t('common.active') : t('common.inactive')}
        </span>
      ),
    },
  ];

  const handleAdd = () => {
    setEditingProvider(null);
    setFormData({
      full_name: '',
      username: '',
      email: '',
      phone: '',
      national_id: '',
      password: '',
      is_active: true,
    });
    setIsModalOpen(true);
  };

  const handleEdit = (provider: Provider) => {
    setEditingProvider(provider);
    setFormData({
      full_name: provider.full_name,
      username: provider.username,
      email: provider.email || '',
      phone: provider.phone || '',
      national_id: provider.national_id || '',
      password: '',
      is_active: provider.is_active,
    });
    setIsModalOpen(true);
  };

  const handleDelete = (provider: Provider) => {
    if (confirm('Are you sure you want to delete this provider?')) {
      setProviders(prev => prev.filter(p => p.id !== provider.id));
    }
  };

  const handleToggleStatus = (provider: Provider) => {
    setProviders(prev => prev.map(p => 
      p.id === provider.id ? { ...p, is_active: !p.is_active } : p
    ));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingProvider) {
      // Update existing provider
      setProviders(prev => prev.map(p => 
        p.id === editingProvider.id 
          ? { ...p, ...formData, updated_at: new Date().toISOString() }
          : p
      ));
    } else {
      // Add new provider
      const newProvider: Provider = {
        id: Date.now().toString(),
        ...formData,
        role: 'provider',
        preferred_language: 'en',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        patients_count: 0,
      };
      setProviders(prev => [...prev, newProvider]);
    }
    
    setIsModalOpen(false);
  };

  const handleExport = () => {
    // Export logic
    console.log('Exporting providers data');
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <UserCheck className="w-8 h-8 text-viking" />
          <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.providers')}</h1>
        </div>
        <button
          onClick={handleAdd}
          className={`flex items-center gap-2 px-4 py-2 bg-viking text-white rounded-lg hover:bg-viking/90 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <Plus className="w-5 h-5" />
          {t('admin.addProvider')}
        </button>
      </div>

      <DataTable
        data={providers}
        columns={columns}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onExport={handleExport}
      />

      {/* Add/Edit Provider Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingProvider ? 'Edit Provider' : 'Add Provider'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('common.name')}
              </label>
              <input
                type="text"
                required
                value={formData.full_name}
                onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('common.username')}
              </label>
              <input
                type="text"
                required
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('common.email')}
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('common.phone')}
              </label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                National ID
              </label>
              <input
                type="text"
                value={formData.national_id}
                onChange={(e) => setFormData(prev => ({ ...prev, national_id: e.target.value }))}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {editingProvider ? 'New Password (leave empty to keep current)' : t('common.password')}
              </label>
              <input
                type="password"
                required={!editingProvider}
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>
          </div>

          <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <input
              type="checkbox"
              id="is_active"
              checked={formData.is_active}
              onChange={(e) => setFormData(prev => ({ ...prev, is_active: e.target.checked }))}
              className="rounded border-gray-300 text-viking focus:ring-viking"
            />
            <label htmlFor="is_active" className="text-sm text-gray-700">
              {t('common.active')}
            </label>
          </div>

          <div className={`flex items-center gap-3 pt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              type="submit"
              className="px-6 py-2 bg-viking text-white rounded-lg hover:bg-viking/90"
            >
              {t('common.save')}
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
            >
              {t('common.cancel')}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AdminProviders;