import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Users, Plus, Eye, FileText } from 'lucide-react';
import DataTable from '../../components/Common/DataTable';
import Modal from '../../components/Common/Modal';
import { Patient, Medication } from '../../types';

const AdminPatients: React.FC = () => {
  const { t, isRTL } = useLanguage();
  const [patients, setPatients] = useState<Patient[]>([
    {
      id: '1',
      username: 'ahmad_patient',
      email: 'ahmad@example.com',
      phone: '+966501234570',
      role: 'patient',
      full_name: 'Ahmad Al-Rashid',
      is_active: true,
      preferred_language: 'ar',
      created_at: '2024-01-15T10:00:00Z',
      updated_at: '2024-01-15T10:00:00Z',
      mrn: 'MRN001',
      date_of_birth: '1985-05-15',
      address: 'Riyadh, Saudi Arabia',
      whatsapp: '+966501234570',
      emergency_contact_1: '+966501234571',
      emergency_contact_2: '+966501234572',
      medical_report: 'Patient presents with diabetes type 2',
      clinical_history: 'Diagnosed with diabetes in 2020',
      physical_exam: 'Normal vital signs',
      care_plan: 'Monitor blood glucose levels daily',
      icd10_codes: ['E11.9'],
      call_frequency_value: 1,
      call_frequency_unit: 'weeks',
      start_date: '2024-01-01',
      end_date: '2024-12-31',
      preferred_voice: 'female',
      preferred_accent: 'saudi',
      suitable_call_time_start: '09:00',
      suitable_call_time_end: '17:00',
      what_to_assess: 'Blood glucose levels, medication compliance',
      assigned_provider_id: '1',
      do_not_call: false,
    },
  ]);

  const [medications, setMedications] = useState<Medication[]>([
    {
      id: '1',
      patient_id: '1',
      name: 'Metformin',
      dosage: '500',
      unit: 'mg',
      frequency: 'twice daily',
      created_at: '2024-01-15T10:00:00Z',
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [viewingPatient, setViewingPatient] = useState<Patient | null>(null);
  const [formData, setFormData] = useState({
    full_name: '',
    username: '',
    email: '',
    phone: '',
    whatsapp: '',
    mrn: '',
    date_of_birth: '',
    address: '',
    emergency_contact_1: '',
    emergency_contact_2: '',
    medical_report: '',
    clinical_history: '',
    physical_exam: '',
    care_plan: '',
    icd10_codes: [] as string[],
    call_frequency_value: 1,
    call_frequency_unit: 'weeks' as 'hours' | 'days' | 'weeks' | 'months' | 'years',
    start_date: '',
    end_date: '',
    preferred_language: 'en' as 'en' | 'ar',
    preferred_voice: 'female',
    preferred_accent: 'neutral',
    suitable_call_time_start: '09:00',
    suitable_call_time_end: '17:00',
    what_to_assess: '',
    assigned_provider_id: '',
    is_active: true,
    do_not_call: false,
    password: '',
  });

  const [patientMedications, setPatientMedications] = useState([
    { name: '', dosage: '', unit: 'mg', frequency: 'once daily' }
  ]);

  const columns = [
    {
      key: 'mrn',
      label: 'MRN',
      sortable: true,
    },
    {
      key: 'full_name',
      label: 'Name',
      sortable: true,
    },
    {
      key: 'date_of_birth',
      label: 'DOB',
      render: (value: string) => new Date(value).toLocaleDateString(),
    },
    {
      key: 'phone',
      label: 'Phone',
    },
    {
      key: 'assigned_provider_id',
      label: 'Provider',
      render: (value: string) => value ? `Provider ${value}` : 'Unassigned',
    },
    {
      key: 'is_active',
      label: 'Status',
      render: (value: boolean) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
          value ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {value ? t('common.active') : t('common.inactive')}
        </span>
      ),
    },
  ];

  const handleAdd = () => {
    setEditingPatient(null);
    setFormData({
      full_name: '',
      username: '',
      email: '',
      phone: '',
      whatsapp: '',
      mrn: '',
      date_of_birth: '',
      address: '',
      emergency_contact_1: '',
      emergency_contact_2: '',
      medical_report: '',
      clinical_history: '',
      physical_exam: '',
      care_plan: '',
      icd10_codes: [],
      call_frequency_value: 1,
      call_frequency_unit: 'weeks',
      start_date: '',
      end_date: '',
      preferred_language: 'en',
      preferred_voice: 'female',
      preferred_accent: 'neutral',
      suitable_call_time_start: '09:00',
      suitable_call_time_end: '17:00',
      what_to_assess: '',
      assigned_provider_id: '',
      is_active: true,
      do_not_call: false,
      password: '',
    });
    setPatientMedications([{ name: '', dosage: '', unit: 'mg', frequency: 'once daily' }]);
    setIsModalOpen(true);
  };

  const handleView = (patient: Patient) => {
    setViewingPatient(patient);
    setIsViewModalOpen(true);
  };

  const handleEdit = (patient: Patient) => {
    setEditingPatient(patient);
    setFormData({
      full_name: patient.full_name,
      username: patient.username,
      email: patient.email || '',
      phone: patient.phone || '',
      whatsapp: patient.whatsapp || '',
      mrn: patient.mrn,
      date_of_birth: patient.date_of_birth,
      address: patient.address || '',
      emergency_contact_1: patient.emergency_contact_1 || '',
      emergency_contact_2: patient.emergency_contact_2 || '',
      medical_report: patient.medical_report || '',
      clinical_history: patient.clinical_history || '',
      physical_exam: patient.physical_exam || '',
      care_plan: patient.care_plan || '',
      icd10_codes: patient.icd10_codes || [],
      call_frequency_value: patient.call_frequency_value || 1,
      call_frequency_unit: patient.call_frequency_unit || 'weeks',
      start_date: patient.start_date || '',
      end_date: patient.end_date || '',
      preferred_language: patient.preferred_language,
      preferred_voice: patient.preferred_voice || 'female',
      preferred_accent: patient.preferred_accent || 'neutral',
      suitable_call_time_start: patient.suitable_call_time_start || '09:00',
      suitable_call_time_end: patient.suitable_call_time_end || '17:00',
      what_to_assess: patient.what_to_assess || '',
      assigned_provider_id: patient.assigned_provider_id || '',
      is_active: patient.is_active,
      do_not_call: patient.do_not_call,
      password: '',
    });
    
    const patientMeds = medications.filter(m => m.patient_id === patient.id);
    setPatientMedications(patientMeds.length > 0 ? 
      patientMeds.map(m => ({ name: m.name, dosage: m.dosage, unit: m.unit, frequency: m.frequency })) :
      [{ name: '', dosage: '', unit: 'mg', frequency: 'once daily' }]
    );
    setIsModalOpen(true);
  };

  const handleDelete = (patient: Patient) => {
    if (confirm('Are you sure you want to delete this patient?')) {
      setPatients(prev => prev.filter(p => p.id !== patient.id));
    }
  };

  const addMedication = () => {
    setPatientMedications(prev => [...prev, { name: '', dosage: '', unit: 'mg', frequency: 'once daily' }]);
  };

  const removeMedication = (index: number) => {
    setPatientMedications(prev => prev.filter((_, i) => i !== index));
  };

  const updateMedication = (index: number, field: string, value: string) => {
    setPatientMedications(prev => prev.map((med, i) => 
      i === index ? { ...med, [field]: value } : med
    ));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingPatient) {
      // Update existing patient
      setPatients(prev => prev.map(p => 
        p.id === editingPatient.id 
          ? { ...p, ...formData, updated_at: new Date().toISOString() }
          : p
      ));
    } else {
      // Add new patient
      const newPatient: Patient = {
        id: Date.now().toString(),
        ...formData,
        role: 'patient',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setPatients(prev => [...prev, newPatient]);
    }
    
    setIsModalOpen(false);
  };

  const handleExport = () => {
    console.log('Exporting patients data');
  };

  return (
    <div className="space-y-6">
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Users className="w-8 h-8 text-viking" />
          <h1 className="text-3xl font-bold text-chathams-blue">{t('nav.patients')}</h1>
        </div>
        <button
          onClick={handleAdd}
          className={`flex items-center gap-2 px-4 py-2 bg-viking text-white rounded-lg hover:bg-viking/90 ${isRTL ? 'flex-row-reverse' : ''}`}
        >
          <Plus className="w-5 h-5" />
          {t('admin.addPatient')}
        </button>
      </div>

      <DataTable
        data={patients}
        columns={columns}
        onView={handleView}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onExport={handleExport}
      />

      {/* Add/Edit Patient Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingPatient ? 'Edit Patient' : 'Add Patient'}
        size="xl"
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Basic Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.mrn')}
                </label>
                <input
                  type="text"
                  required
                  value={formData.mrn}
                  onChange={(e) => setFormData(prev => ({ ...prev, mrn: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('common.name')}
                </label>
                <input
                  type="text"
                  required
                  value={formData.full_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, full_name: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('common.username')}
                </label>
                <input
                  type="text"
                  required
                  value={formData.username}
                  onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {editingPatient ? 'New Password (leave empty to keep current)' : t('common.password')}
                </label>
                <input
                  type="password"
                  required={!editingPatient}
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.dateOfBirth')}
                </label>
                <input
                  type="date"
                  required
                  value={formData.date_of_birth}
                  onChange={(e) => setFormData(prev => ({ ...prev, date_of_birth: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('common.phone')}
                </label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.whatsapp')}
                </label>
                <input
                  type="tel"
                  value={formData.whatsapp}
                  onChange={(e) => setFormData(prev => ({ ...prev, whatsapp: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('common.email')}
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('form.address')}
              </label>
              <textarea
                value={formData.address}
                onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                rows={2}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.emergencyContact1')}
                </label>
                <input
                  type="tel"
                  value={formData.emergency_contact_1}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact_1: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.emergencyContact2')}
                </label>
                <input
                  type="tel"
                  value={formData.emergency_contact_2}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact_2: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>
            </div>
          </div>

          {/* Medical Information */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Medical Information</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.medicalReport')}
                </label>
                <textarea
                  value={formData.medical_report}
                  onChange={(e) => setFormData(prev => ({ ...prev, medical_report: e.target.value }))}
                  rows={3}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.clinicalHistory')}
                </label>
                <textarea
                  value={formData.clinical_history}
                  onChange={(e) => setFormData(prev => ({ ...prev, clinical_history: e.target.value }))}
                  rows={3}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('form.carePlan')}
                </label>
                <textarea
                  value={formData.care_plan}
                  onChange={(e) => setFormData(prev => ({ ...prev, care_plan: e.target.value }))}
                  rows={3}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>
            </div>
          </div>

          {/* Medications */}
          <div>
            <div className={`flex items-center justify-between mb-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <h3 className="text-lg font-medium text-gray-900">{t('form.medications')}</h3>
              <button
                type="button"
                onClick={addMedication}
                className="px-3 py-1 bg-viking text-white rounded text-sm hover:bg-viking/90"
              >
                Add Medication
              </button>
            </div>
            <div className="space-y-3">
              {patientMedications.map((med, index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-5 gap-3 p-3 bg-gray-50 rounded-lg">
                  <input
                    type="text"
                    placeholder="Medication name"
                    value={med.name}
                    onChange={(e) => updateMedication(index, 'name', e.target.value)}
                    className={`px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                  />
                  <input
                    type="text"
                    placeholder="Dosage"
                    value={med.dosage}
                    onChange={(e) => updateMedication(index, 'dosage', e.target.value)}
                    className={`px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                  />
                  <select
                    value={med.unit}
                    onChange={(e) => updateMedication(index, 'unit', e.target.value)}
                    className={`px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                  >
                    <option value="mg">mg</option>
                    <option value="g">g</option>
                    <option value="ml">ml</option>
                    <option value="tablets">tablets</option>
                  </select>
                  <select
                    value={med.frequency}
                    onChange={(e) => updateMedication(index, 'frequency', e.target.value)}
                    className={`px-3 py-2 border border-gray-300 rounded focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                  >
                    <option value="once daily">Once daily</option>
                    <option value="twice daily">Twice daily</option>
                    <option value="three times daily">Three times daily</option>
                    <option value="as needed">As needed</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => removeMedication(index)}
                    className="px-3 py-2 bg-red-100 text-red-600 rounded hover:bg-red-200"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Call Settings */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Call Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Call Frequency
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    value={formData.call_frequency_value}
                    onChange={(e) => setFormData(prev => ({ ...prev, call_frequency_value: parseInt(e.target.value) }))}
                    className={`w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                  />
                  <select
                    value={formData.call_frequency_unit}
                    onChange={(e) => setFormData(prev => ({ ...prev, call_frequency_unit: e.target.value as any }))}
                    className={`flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                  >
                    <option value="hours">Hours</option>
                    <option value="days">Days</option>
                    <option value="weeks">Weeks</option>
                    <option value="months">Months</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Assigned Provider
                </label>
                <select
                  value={formData.assigned_provider_id}
                  onChange={(e) => setFormData(prev => ({ ...prev, assigned_provider_id: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                >
                  <option value="">Select Provider</option>
                  <option value="1">Dr. Sarah Johnson</option>
                  <option value="2">Dr. Ahmed Al-Rashid</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Call Time Start
                </label>
                <input
                  type="time"
                  value={formData.suitable_call_time_start}
                  onChange={(e) => setFormData(prev => ({ ...prev, suitable_call_time_start: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Call Time End
                </label>
                <input
                  type="time"
                  value={formData.suitable_call_time_end}
                  onChange={(e) => setFormData(prev => ({ ...prev, suitable_call_time_end: e.target.value }))}
                  className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
                />
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                What to Assess
              </label>
              <textarea
                value={formData.what_to_assess}
                onChange={(e) => setFormData(prev => ({ ...prev, what_to_assess: e.target.value }))}
                rows={2}
                className={`w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-viking focus:border-viking ${isRTL ? 'text-right' : ''}`}
              />
            </div>

            <div className={`flex items-center gap-4 mt-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <label className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <input
                  type="checkbox"
                  checked={formData.is_active}
                  onChange={(e) => setFormData(prev => ({ ...prev, is_active: e.target.checked }))}
                  className="rounded border-gray-300 text-viking focus:ring-viking"
                />
                <span className="text-sm text-gray-700">{t('common.active')}</span>
              </label>

              <label className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <input
                  type="checkbox"
                  checked={formData.do_not_call}
                  onChange={(e) => setFormData(prev => ({ ...prev, do_not_call: e.target.checked }))}
                  className="rounded border-gray-300 text-viking focus:ring-viking"
                />
                <span className="text-sm text-gray-700">Do Not Call</span>
              </label>
            </div>
          </div>

          <div className={`flex items-center gap-3 pt-4 border-t ${isRTL ? 'flex-row-reverse' : ''}`}>
            <button
              type="submit"
              className="px-6 py-2 bg-viking text-white rounded-lg hover:bg-viking/90"
            >
              {t('common.save')}
            </button>
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
            >
              {t('common.cancel')}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Patient Modal */}
      <Modal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title={`Patient File: ${viewingPatient?.full_name}`}
        size="xl"
      >
        {viewingPatient && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">MRN</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.mrn}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Date of Birth</label>
                <p className="mt-1 text-sm text-gray-900">{new Date(viewingPatient.date_of_birth).toLocaleDateString()}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Phone</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.phone}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Email</label>
                <p className="mt-1 text-sm text-gray-900">{viewingPatient.email || 'N/A'}</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Medical Report</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.medical_report || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Care Plan</label>
              <p className="mt-1 text-sm text-gray-900 bg-gray-50 p-3 rounded">{viewingPatient.care_plan || 'N/A'}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Medications</label>
              <div className="mt-1 space-y-2">
                {medications.filter(m => m.patient_id === viewingPatient.id).map(med => (
                  <div key={med.id} className="bg-gray-50 p-2 rounded text-sm">
                    {med.name} - {med.dosage}{med.unit} - {med.frequency}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default AdminPatients;