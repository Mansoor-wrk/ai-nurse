import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import Landing from './pages/Landing';
import Layout from './components/Layout/Layout';
import ProtectedRoute from './components/Common/ProtectedRoute';

// Admin Pages
import AdminDashboard from './pages/Admin/Dashboard';
import AdminSettings from './pages/Admin/Settings';
import AdminProviders from './pages/Admin/Providers';
import AdminPatients from './pages/Admin/Patients';
import AdminCallLogs from './pages/Admin/CallLogs';
import AdminFinancialReports from './pages/Admin/FinancialReports';
import AdminExportData from './pages/Admin/ExportData';
import AdminMainPrompt from './pages/Admin/MainPrompt';

// Provider Pages
import ProviderDashboard from './pages/Provider/Dashboard';
import ProviderPatients from './pages/Provider/Patients';
import ProviderCallLogs from './pages/Provider/CallLogs';
import ProviderSettings from './pages/Provider/Settings';

// Patient Pages
import PatientDashboard from './pages/Patient/Dashboard';
import PatientSettings from './pages/Patient/Settings';
import PatientCarePlan from './pages/Patient/CarePlan';
import PatientHelpCenter from './pages/Patient/HelpCenter';

const App: React.FC = () => {
  return (
    <LanguageProvider>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Routes>
              {/* Landing Page */}
              <Route path="/" element={<Landing />} />
              
              {/* Admin Routes */}
              <Route path="/admin/*" element={
                <ProtectedRoute allowedRoles={['admin']}>
                  <Layout />
                </ProtectedRoute>
              }>
                <Route path="dashboard" element={<AdminDashboard />} />
                <Route path="settings" element={<AdminSettings />} />
                <Route path="providers" element={<AdminProviders />} />
                <Route path="patients" element={<AdminPatients />} />
                <Route path="call-logs" element={<AdminCallLogs />} />
                <Route path="financial-reports" element={<AdminFinancialReports />} />
                <Route path="export-data" element={<AdminExportData />} />
                <Route path="main-prompt" element={<AdminMainPrompt />} />
              </Route>
              
              {/* Provider Routes */}
              <Route path="/provider/*" element={
                <ProtectedRoute allowedRoles={['provider']}>
                  <Layout />
                </ProtectedRoute>
              }>
                <Route path="dashboard" element={<ProviderDashboard />} />
                <Route path="patients" element={<ProviderPatients />} />
                <Route path="call-logs" element={<ProviderCallLogs />} />
                <Route path="settings" element={<ProviderSettings />} />
              </Route>
              
              {/* Patient Routes */}
              <Route path="/patient/*" element={
                <ProtectedRoute allowedRoles={['patient']}>
                  <Layout />
                </ProtectedRoute>
              }>
                <Route path="dashboard" element={<PatientDashboard />} />
                <Route path="settings" element={<PatientSettings />} />
                <Route path="care-plan" element={<PatientCarePlan />} />
                <Route path="help-center" element={<PatientHelpCenter />} />
              </Route>
            </Routes>
          </div>
        </Router>
      </AuthProvider>
    </LanguageProvider>
  );
};

export default App;