import React, { createContext, useContext, ReactNode } from 'react';

interface LanguageContextType {
  t: (key: string) => string;
  isRTL: boolean;
}

const translations = {
  // Authentication
  username: 'Username',
  password: 'Password',
  rememberMe: 'Remember Me',
  forgotPassword: 'Forgot Password?',
  login: 'Login',
  logout: 'Logout',
  loading: 'Loading...',
  
  // User Types
  admin: 'Admin',
  provider: 'Provider',
  patient: 'Patient',
  
  // Navigation
  dashboard: 'Dashboard',
  settings: 'Settings',
  patients: 'Patients',
  providers: 'Providers',
  callLogs: 'Call Logs',
  financialReports: 'Financial Reports',
  exportData: 'Export Data',
  carePlan: 'Care Plan',
  helpCenter: 'Help Center',
  mainPrompt: 'Main Prompt',
  navigation: 'Navigation',
  myPatients: 'My Patients',
  myCarePlan: 'My Care Plan',
  
  // Common
  save: 'Save',
  cancel: 'Cancel',
  edit: 'Edit',
  delete: 'Delete',
  add: 'Add',
  search: 'Search',
  filter: 'Filter',
  export: 'Export',
  import: 'Import',
  actions: 'Actions',
  active: 'Active',
  inactive: 'Inactive',
  name: 'Name',
  email: 'Email',
  phone: 'Phone',
  
  // Patient Fields
  mrn: 'MRN',
  firstName: 'First Name',
  lastName: 'Last Name',
  dateOfBirth: 'Date of Birth',
  gender: 'Gender',
  whatsapp: 'WhatsApp',
  address: 'Address',
  emergencyContact1: 'Emergency Contact 1',
  emergencyContact2: 'Emergency Contact 2',
  medicalReport: 'Medical Report',
  clinicalHistory: 'Clinical History',
  carePlan: 'Care Plan',
  medications: 'Medications',
  doNotCall: 'Do Not Call',
  
  // Admin specific
  addProvider: 'Add Provider',
  addPatient: 'Add Patient',
  
  // Provider specific
  callProvider: 'Call Provider',
  
  // Patient specific
  callAdmin: 'Call Admin',
  
  // Messages
  saveSuccess: 'Settings saved successfully!',
  loginSuccess: 'Login successful!',
  loginFailed: 'Login failed. Please check your credentials.',
  
  // Landing Page
  welcomeTitle: 'Welcome to Advanced Healthcare Platform',
  getStarted: 'Get Started',
  learnMore: 'Learn More',
  
  // Portal Titles
  adminPortal: 'Admin Portal',
  providerPortal: 'Provider Portal',
  patientPortal: 'Patient Portal',
  
  // Landing page role descriptions
  'landing.admin': 'Admin',
  'landing.provider': 'Provider', 
  'landing.patient': 'Patient',
  
  // Navigation items
  'nav.dashboard': 'Dashboard',
  'nav.settings': 'Settings',
  'nav.patients': 'Patients',
  'nav.providers': 'Providers',
  'nav.callLogs': 'Call Logs',
  'nav.financialReports': 'Financial Reports',
  'nav.exportData': 'Export Data',
  'nav.myCareplan': 'My Care Plan',
  'nav.helpCenter': 'Help Center',
  
  // Page titles
  'admin.title': 'Admin Dashboard',
  'provider.title': 'Provider Dashboard',
  'patient.title': 'Patient Dashboard',
  
  // Form labels
  'form.mrn': 'MRN',
  'form.dateOfBirth': 'Date of Birth',
  'form.whatsapp': 'WhatsApp',
  'form.address': 'Address',
  'form.emergencyContact1': 'Emergency Contact 1',
  'form.emergencyContact2': 'Emergency Contact 2',
  'form.medicalReport': 'Medical Report',
  'form.clinicalHistory': 'Clinical History',
  'form.carePlan': 'Care Plan',
  'form.medications': 'Medications',
  
  // Messages
  'msg.loginFailed': 'Login failed. Please check your credentials.',
  
  // Common actions
  'common.username': 'Username',
  'common.password': 'Password',
  'common.email': 'Email',
  'common.phone': 'Phone',
  'common.name': 'Name',
  'common.save': 'Save',
  'common.cancel': 'Cancel',
  'common.login': 'Login',
  'common.logout': 'Logout',
  'common.loading': 'Loading...',
  'common.search': 'Search',
  'common.filter': 'Filter',
  'common.export': 'Export',
  'common.actions': 'Actions',
  'common.active': 'Active',
  'common.inactive': 'Inactive',
  'common.rememberMe': 'Remember Me',
  'common.forgotPassword': 'Forgot Password?',
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const t = (key: string): string => {
    return translations[key as keyof typeof translations] || key;
  };

  const value: LanguageContextType = {
    t,
    isRTL: false, // Always false for English-only
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};