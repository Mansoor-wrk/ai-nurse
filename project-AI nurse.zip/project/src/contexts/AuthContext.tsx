import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { BaseUser, SystemSettings } from '../types';

interface AuthContextType {
  user: BaseUser | null;
  isLoading: boolean;
  systemSettings: SystemSettings;
  login: (username: string, password: string, expectedRole?: string) => Promise<boolean>;
  logout: () => void;
  updateSystemSettings: (settings: Partial<SystemSettings>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for demo
const mockUsers: BaseUser[] = [
  {
    id: '1',
    username: 'admin',
    email: 'admin@telenurse.com',
    phone: '+966501234567',
    role: 'admin',
    full_name: 'System Administrator',
    is_active: true,
    preferred_language: 'en',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    username: 'provider',
    email: 'provider@telenurse.com',
    phone: '+966501234568',
    role: 'provider',
    full_name: 'Dr. Sarah Johnson',
    is_active: true,
    preferred_language: 'en',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
  },
  {
    id: '3',
    username: 'patient',
    email: 'patient@telenurse.com',
    phone: '+966501234569',
    role: 'patient',
    full_name: 'Ahmad Al-Rashid',
    is_active: true,
    preferred_language: 'ar',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
  },
];

const defaultSystemSettings: SystemSettings = {
  systemName: 'AI Tele-Nurse',
  systemSlogan: 'Advanced Healthcare Platform with AI-Powered Remote Patient Monitoring',
  headerLogoUrl: '',
  portalLogoUrl: '',
  adminEmail: 'admin@telenurse.com',
  adminPhone: '+966501234567',
  costPerMinute: 2.5,
  llm_provider: 'openai',
  api_key: '',
  model: 'gpt-4',
  temperature: 0.3,
  max_tokens: 2000,
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<BaseUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [systemSettings, setSystemSettings] = useState<SystemSettings>(defaultSystemSettings);

  useEffect(() => {
    // Check for stored user on app load
    const storedUser = localStorage.getItem('user');
    const storedSettings = localStorage.getItem('systemSettings');
    
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Error parsing stored user:', error);
        localStorage.removeItem('user');
      }
    }
    
    if (storedSettings) {
      try {
        setSystemSettings({ ...defaultSystemSettings, ...JSON.parse(storedSettings) });
      } catch (error) {
        console.error('Error parsing stored settings:', error);
        localStorage.removeItem('systemSettings');
      }
    }
    
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string, expectedRole?: string): Promise<boolean> => {
    // Simple mock authentication
    const foundUser = mockUsers.find(u => u.username === username && username === password);
    
    if (foundUser) {
      // Check if the user's role matches the expected role (if provided)
      if (expectedRole && foundUser.role !== expectedRole) {
        return false;
      }
      
      setUser(foundUser);
      localStorage.setItem('user', JSON.stringify(foundUser));
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateSystemSettings = (newSettings: Partial<SystemSettings>) => {
    const updatedSettings = { ...systemSettings, ...newSettings };
    setSystemSettings(updatedSettings);
    localStorage.setItem('systemSettings', JSON.stringify(updatedSettings));
  };

  const value: AuthContextType = {
    user,
    isLoading,
    systemSettings,
    login,
    logout,
    updateSystemSettings,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};